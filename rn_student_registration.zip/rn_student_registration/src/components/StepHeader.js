// src/components/StepHeader.js
// Reusable "Step X of 3" header with a progress bar.
// CONCEPTS: a custom component, props, Array.map to render a list, StyleSheet.

import React from 'react';
import { View, Text, StyleSheet } from 'react-native';
import { COLORS } from '../theme';

export default function StepHeader({ currentStep, title }) {
  return (
    <View style={styles.wrapper}>
      <Text style={styles.step}>Step {currentStep} of 3</Text>
      <Text style={styles.title}>{title}</Text>
      <View style={styles.row}>
        {[1, 2, 3].map((n) => (
          <View
            key={n}
            style={[styles.bar, n <= currentStep && styles.barDone]}
          />
        ))}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  wrapper: { marginBottom: 20 },
  step: { color: COLORS.primary, fontWeight: '600' },
  title: { fontSize: 24, color: COLORS.text, marginTop: 4, marginBottom: 12 },
  row: { flexDirection: 'row' },
  bar: {
    flex: 1,
    height: 6,
    borderRadius: 3,
    marginRight: 6,
    backgroundColor: COLORS.primaryLight,
  },
  barDone: { backgroundColor: COLORS.primary },
});
