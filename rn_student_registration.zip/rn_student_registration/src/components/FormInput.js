// src/components/FormInput.js
// A labelled TextInput that shows an error message underneath.
// CONCEPTS: controlled TextInput (value + onChangeText), props spreading,
// conditional rendering with &&.

import React from 'react';
import { View, Text, TextInput, StyleSheet } from 'react-native';
import { COLORS } from '../theme';

export default function FormInput({ label, value, onChangeText, error, prefix, ...rest }) {
  return (
    <View style={styles.container}>
      <Text style={styles.label}>{label}</Text>
      <View style={[styles.inputRow, error && styles.inputRowError]}>
        {prefix ? <Text style={styles.prefix}>{prefix}</Text> : null}
        <TextInput
          style={styles.input}
          value={value}
          onChangeText={onChangeText}
          placeholderTextColor={COLORS.muted}
          {...rest} // keyboardType, maxLength, autoCapitalize, placeholder...
        />
      </View>
      {error ? <Text style={styles.error}>{error}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { marginBottom: 16 },
  label: { fontSize: 14, fontWeight: '600', color: COLORS.text, marginBottom: 6 },
  inputRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 8,
    backgroundColor: COLORS.white,
    paddingHorizontal: 12,
  },
  inputRowError: { borderColor: COLORS.error },
  prefix: { fontSize: 16, color: COLORS.muted, marginRight: 4 },
  input: { flex: 1, fontSize: 16, paddingVertical: 12, color: COLORS.text },
  error: { color: COLORS.error, fontSize: 13, marginTop: 4 },
});
