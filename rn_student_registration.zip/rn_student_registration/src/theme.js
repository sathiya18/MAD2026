// src/theme.js — shared colours, so every screen looks consistent.
// (Flutter does this with ThemeData; React Native has no built-in theme,
//  so we export plain JavaScript constants.)

export const COLORS = {
  primary: '#3F51B5',
  primaryLight: '#E8EAF6',
  accent: '#7E57C2',
  text: '#1C1B1F',
  muted: '#6B6B76',
  border: '#C7C7D1',
  error: '#C62828',
  success: '#2E7D32',
  background: '#F7F7FB',
  white: '#FFFFFF',
};
