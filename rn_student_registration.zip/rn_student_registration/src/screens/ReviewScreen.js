// src/screens/ReviewScreen.js
// SCREEN 2 — summary of entered details.
// CONCEPTS: reading route.params, async/await with setTimeout,
// ActivityIndicator + loading state, navigation.popTo / navigation.reset.

import React, { useState } from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet, ActivityIndicator } from 'react-native';

import StepHeader from '../components/StepHeader';
import { COLORS } from '../theme';

// Simulates sending data to a server (returns a Promise).
const fakeApiSubmit = () => new Promise((resolve) => setTimeout(resolve, 2000));

export default function ReviewScreen({ navigation, route }) {
  const { student } = route.params; // data passed from Screen 1
  const [loading, setLoading] = useState(false);

  const submit = async () => {
    setLoading(true);
    await fakeApiSubmit();
    setLoading(false);

    const registrationId = `REG-${new Date().getFullYear()}-${1000 + Math.floor(Math.random() * 9000)}`;

    // reset() replaces the whole stack, so Back cannot return to the form.
    navigation.reset({
      index: 0,
      routes: [{ name: 'Success', params: { student: { ...student, registrationId } } }],
    });
  };

  const rows = [
    ['Full Name', student.fullName],
    ['Register No.', student.registerNumber],
    ['Email', student.email],
    ['Phone', `+91 ${student.phone}`],
    ['Department', student.department],
    ['Year', student.year],
    ['Gender', student.gender],
  ];

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <StepHeader currentStep={2} title="Check before submitting" />

      <View style={styles.card}>
        {rows.map(([label, value], i) => (
          <View key={label} style={[styles.row, i < rows.length - 1 && styles.divider]}>
            <Text style={styles.rowLabel}>{label}</Text>
            <Text style={styles.rowValue}>{value}</Text>
          </View>
        ))}
      </View>

      <Pressable
        onPress={submit}
        disabled={loading}
        style={({ pressed }) => [styles.button, (pressed || loading) && { opacity: 0.8 }]}
      >
        {loading ? (
          <ActivityIndicator color={COLORS.white} />
        ) : (
          <Text style={styles.buttonText}>✓  Confirm & Submit</Text>
        )}
      </Pressable>

      <Pressable
        disabled={loading}
        // popTo goes back to the existing Register screen and updates its params,
        // so the form shows the same data for editing.
        onPress={() => navigation.popTo('Register', { student })}
        style={({ pressed }) => [styles.outlineButton, pressed && { opacity: 0.7 }]}
      >
        <Text style={styles.outlineText}>✎  Back to Edit</Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.background },
  content: { padding: 20, paddingBottom: 40 },
  card: {
    backgroundColor: COLORS.white,
    borderRadius: 12,
    paddingHorizontal: 16,
    // Shadow: iOS uses shadow*, Android uses elevation.
    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 8,
    shadowOffset: { width: 0, height: 2 },
    elevation: 2,
  },
  row: { paddingVertical: 12 },
  divider: { borderBottomWidth: StyleSheet.hairlineWidth, borderBottomColor: COLORS.border },
  rowLabel: { fontSize: 13, color: COLORS.muted },
  rowValue: { fontSize: 16, fontWeight: '600', color: COLORS.text, marginTop: 2 },
  button: {
    marginTop: 24,
    backgroundColor: COLORS.primary,
    paddingVertical: 16,
    borderRadius: 28,
    alignItems: 'center',
  },
  buttonText: { color: COLORS.white, fontSize: 16, fontWeight: '600' },
  outlineButton: {
    marginTop: 12,
    borderWidth: 1.5,
    borderColor: COLORS.primary,
    paddingVertical: 15,
    borderRadius: 28,
    alignItems: 'center',
  },
  outlineText: { color: COLORS.primary, fontSize: 16, fontWeight: '600' },
});
