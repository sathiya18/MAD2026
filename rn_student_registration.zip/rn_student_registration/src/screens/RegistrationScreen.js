// src/screens/RegistrationScreen.js
// SCREEN 1 — the registration form.
// CONCEPTS: useState hook, controlled inputs, one state object for the form,
// Picker (dropdown), Pressable chips & radio buttons, KeyboardAvoidingView,
// ScrollView, navigation.navigate('Review', params), useEffect + route.params.

import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  ScrollView,
  Pressable,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
} from 'react-native';
import { Picker } from '@react-native-picker/picker';

import StepHeader from '../components/StepHeader';
import FormInput from '../components/FormInput';
import { validateStudent } from '../validation';
import { COLORS } from '../theme';

const DEPARTMENTS = [
  'Computer Science',
  'Information Technology',
  'Electronics & Communication',
  'Electrical & Electronics',
  'Mechanical',
  'Civil',
];
const YEARS = ['1st Year', '2nd Year', '3rd Year', '4th Year'];
const GENDERS = ['Female', 'Male', 'Other'];

const EMPTY_FORM = {
  fullName: '',
  registerNumber: '',
  email: '',
  phone: '',
  department: '',
  year: '1st Year',
  gender: 'Female',
};

export default function RegistrationScreen({ navigation, route }) {
  // useState returns [currentValue, setterFunction].
  // Calling the setter re-renders the screen with the new value.
  const [form, setForm] = useState(EMPTY_FORM);
  const [errors, setErrors] = useState({});

  // When we come back from Review with "Edit", route.params.student is set.
  // useEffect runs after render whenever the values in [] change.
  useEffect(() => {
    if (route.params?.student) setForm(route.params.student);
  }, [route.params?.student]);

  // Helper: update ONE field and clear its error.
  // We copy the old object with ...form (state must not be mutated directly).
  const update = (field, value) => {
    setForm((prev) => ({ ...prev, [field]: value }));
    setErrors((prev) => ({ ...prev, [field]: undefined }));
  };

  const goToReview = () => {
    const found = validateStudent(form);
    setErrors(found);
    if (Object.keys(found).length > 0) return; // stop if any error

    const student = {
      ...form,
      fullName: form.fullName.trim(),
      registerNumber: form.registerNumber.trim().toUpperCase(),
      email: form.email.trim(),
    };
    // Move to screen 2, passing data as route params.
    navigation.navigate('Review', { student });
  };

  return (
    <KeyboardAvoidingView
      style={{ flex: 1 }}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView
        style={styles.screen}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
      >
        <StepHeader currentStep={1} title="Enter your details" />

        <FormInput
          label="Full Name"
          value={form.fullName}
          onChangeText={(t) => update('fullName', t)}
          error={errors.fullName}
          placeholder="e.g. Priya Raman"
          autoCapitalize="words"
        />
        <FormInput
          label="Register Number"
          value={form.registerNumber}
          onChangeText={(t) => update('registerNumber', t)}
          error={errors.registerNumber}
          placeholder="e.g. 21CS1045"
          autoCapitalize="characters"
        />
        <FormInput
          label="Email"
          value={form.email}
          onChangeText={(t) => update('email', t)}
          error={errors.email}
          placeholder="name@college.edu"
          keyboardType="email-address"
          autoCapitalize="none"
        />
        <FormInput
          label="Phone Number"
          prefix="+91"
          value={form.phone}
          onChangeText={(t) => update('phone', t.replace(/[^0-9]/g, ''))}
          error={errors.phone}
          keyboardType="phone-pad"
          maxLength={10}
        />

        {/* Dropdown */}
        <Text style={styles.label}>Department</Text>
        <View style={[styles.pickerBox, errors.department && styles.errorBorder]}>
          <Picker
            selectedValue={form.department}
            onValueChange={(v) => update('department', v)}
          >
            <Picker.Item label="Select department..." value="" color={COLORS.muted} />
            {DEPARTMENTS.map((d) => (
              <Picker.Item key={d} label={d} value={d} />
            ))}
          </Picker>
        </View>
        {errors.department ? <Text style={styles.error}>{errors.department}</Text> : null}

        {/* Choice chips */}
        <Text style={[styles.label, { marginTop: 16 }]}>Year of Study</Text>
        <View style={styles.chipRow}>
          {YEARS.map((y) => {
            const selected = form.year === y;
            return (
              <Pressable
                key={y}
                onPress={() => update('year', y)}
                style={[styles.chip, selected && styles.chipSelected]}
              >
                <Text style={[styles.chipText, selected && styles.chipTextSelected]}>{y}</Text>
              </Pressable>
            );
          })}
        </View>

        {/* Radio buttons (built by hand — RN has no built-in radio) */}
        <Text style={[styles.label, { marginTop: 16 }]}>Gender</Text>
        {GENDERS.map((g) => (
          <Pressable key={g} style={styles.radioRow} onPress={() => update('gender', g)}>
            <View style={styles.radioOuter}>
              {form.gender === g ? <View style={styles.radioInner} /> : null}
            </View>
            <Text style={styles.radioLabel}>{g}</Text>
          </Pressable>
        ))}

        <Pressable
          onPress={goToReview}
          style={({ pressed }) => [styles.button, pressed && { opacity: 0.85 }]}
        >
          <Text style={styles.buttonText}>Review Details  →</Text>
        </Pressable>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.background },
  content: { padding: 20, paddingBottom: 40 },
  label: { fontSize: 14, fontWeight: '600', color: COLORS.text, marginBottom: 6 },
  pickerBox: {
    borderWidth: 1,
    borderColor: COLORS.border,
    borderRadius: 8,
    backgroundColor: COLORS.white,
    overflow: 'hidden',
  },
  errorBorder: { borderColor: COLORS.error },
  error: { color: COLORS.error, fontSize: 13, marginTop: 4 },
  chipRow: { flexDirection: 'row', flexWrap: 'wrap' },
  chip: {
    paddingVertical: 8,
    paddingHorizontal: 14,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: COLORS.border,
    marginRight: 8,
    marginBottom: 8,
    backgroundColor: COLORS.white,
  },
  chipSelected: { backgroundColor: COLORS.primaryLight, borderColor: COLORS.primary },
  chipText: { color: COLORS.text },
  chipTextSelected: { color: COLORS.primary, fontWeight: '600' },
  radioRow: { flexDirection: 'row', alignItems: 'center', paddingVertical: 8 },
  radioOuter: {
    width: 22,
    height: 22,
    borderRadius: 11,
    borderWidth: 2,
    borderColor: COLORS.primary,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  radioInner: { width: 11, height: 11, borderRadius: 6, backgroundColor: COLORS.primary },
  radioLabel: { fontSize: 16, color: COLORS.text },
  button: {
    marginTop: 24,
    backgroundColor: COLORS.primary,
    paddingVertical: 16,
    borderRadius: 28,
    alignItems: 'center',
  },
  buttonText: { color: COLORS.white, fontSize: 16, fontWeight: '600' },
});
