// src/screens/SuccessScreen.js
// SCREEN 3 — confirmation and digital ID card.
// CONCEPTS: layout with Flexbox, absolute styling, BackHandler (Android back
// button) via useFocusEffect, navigation.reset to start over.

import React, { useCallback } from 'react';
import { View, Text, ScrollView, Pressable, StyleSheet, BackHandler } from 'react-native';
import { useFocusEffect } from '@react-navigation/native';

import StepHeader from '../components/StepHeader';
import { COLORS } from '../theme';

export default function SuccessScreen({ navigation, route }) {
  const { student } = route.params;

  const initials = student.fullName
    .split(' ')
    .filter(Boolean)
    .slice(0, 2)
    .map((p) => p[0].toUpperCase())
    .join('');

  const registerAnother = useCallback(() => {
    navigation.reset({ index: 0, routes: [{ name: 'Register' }] });
  }, [navigation]);

  // Android hardware Back on this screen → fresh form instead of exiting.
  useFocusEffect(
    useCallback(() => {
      const sub = BackHandler.addEventListener('hardwareBackPress', () => {
        registerAnother();
        return true; // true = "we handled it"
      });
      return () => sub.remove(); // cleanup when screen loses focus
    }, [registerAnother])
  );

  return (
    <ScrollView style={styles.screen} contentContainerStyle={styles.content}>
      <StepHeader currentStep={3} title="Registration complete" />

      <View style={styles.tick}>
        <Text style={styles.tickMark}>✓</Text>
      </View>
      <Text style={styles.welcome}>Welcome, {student.fullName.split(' ')[0]}!</Text>
      <Text style={styles.sub}>Your registration was submitted successfully.</Text>

      {/* Digital ID card */}
      <View style={styles.idCard}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>{initials}</Text>
        </View>
        <View style={{ flex: 1 }}>
          <Text style={styles.cardName}>{student.fullName}</Text>
          <Text style={styles.cardLine}>{student.registerNumber}</Text>
          <Text style={styles.cardLine}>
            {student.department} · {student.year}
          </Text>
          <Text style={styles.cardId}>ID: {student.registrationId}</Text>
        </View>
      </View>

      <Pressable
        onPress={registerAnother}
        style={({ pressed }) => [styles.button, pressed && { opacity: 0.85 }]}
      >
        <Text style={styles.buttonText}>＋  Register Another Student</Text>
      </Pressable>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  screen: { flex: 1, backgroundColor: COLORS.background },
  content: { padding: 20, paddingBottom: 40 },
  tick: {
    alignSelf: 'center',
    width: 80,
    height: 80,
    borderRadius: 40,
    backgroundColor: COLORS.success,
    alignItems: 'center',
    justifyContent: 'center',
  },
  tickMark: { color: COLORS.white, fontSize: 44, fontWeight: '700' },
  welcome: { fontSize: 22, fontWeight: '600', textAlign: 'center', marginTop: 12, color: COLORS.text },
  sub: { textAlign: 'center', color: COLORS.muted, marginTop: 4 },
  idCard: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 24,
    padding: 20,
    borderRadius: 16,
    backgroundColor: COLORS.primary, // RN core has no gradient; solid colour here
  },
  avatar: {
    width: 64,
    height: 64,
    borderRadius: 32,
    backgroundColor: COLORS.white,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 16,
  },
  avatarText: { fontSize: 22, fontWeight: '700', color: COLORS.primary },
  cardName: { color: COLORS.white, fontSize: 18, fontWeight: '700' },
  cardLine: { color: 'rgba(255,255,255,0.75)', marginTop: 2 },
  cardId: { color: COLORS.white, fontWeight: '600', letterSpacing: 1, marginTop: 8 },
  button: {
    marginTop: 32,
    backgroundColor: COLORS.primary,
    paddingVertical: 16,
    borderRadius: 28,
    alignItems: 'center',
  },
  buttonText: { color: COLORS.white, fontSize: 16, fontWeight: '600' },
});
