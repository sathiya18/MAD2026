// src/validation.js
// Pure JavaScript validation. Returns an object of { fieldName: 'message' }.
// An empty object means the form is valid.
// (In Flutter each field has its own validator; in React Native we usually
//  validate the whole form object in one function like this.)

export function validateStudent(form) {
  const errors = {};

  if (!form.fullName.trim()) errors.fullName = 'Please enter your name';
  else if (form.fullName.trim().length < 3) errors.fullName = 'Name must have at least 3 letters';

  if (form.registerNumber.trim().length < 6)
    errors.registerNumber = 'Enter a valid register number (min 6 characters)';

  if (!/^[\w.+-]+@[\w-]+\.[\w.]+$/.test(form.email.trim()))
    errors.email = 'Enter a valid email address';

  if (!/^[6-9]\d{9}$/.test(form.phone)) errors.phone = 'Enter a valid 10-digit mobile number';

  if (!form.department) errors.department = 'Please choose a department';

  return errors;
}
