// App.js
// Entry component of the React Native app.
// CONCEPTS: function components, JSX, NavigationContainer,
// createNativeStackNavigator, Stack.Screen, screen options.

import React from 'react';
import { StatusBar } from 'expo-status-bar';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { SafeAreaProvider } from 'react-native-safe-area-context';

import RegistrationScreen from './src/screens/RegistrationScreen';
import ReviewScreen from './src/screens/ReviewScreen';
import SuccessScreen from './src/screens/SuccessScreen';
import { COLORS } from './src/theme';

// A "stack" navigator: each new screen is pushed on top of the previous one,
// and Back pops it off — the same idea as Android's Activity back stack.
const Stack = createNativeStackNavigator();

export default function App() {
  return (
    <SafeAreaProvider>
      <NavigationContainer>
        <StatusBar style="light" />
        <Stack.Navigator
          initialRouteName="Register"
          screenOptions={{
            headerStyle: { backgroundColor: COLORS.primary },
            headerTintColor: '#fff',
            headerTitleStyle: { fontWeight: '600' },
          }}
        >
          <Stack.Screen
            name="Register"
            component={RegistrationScreen}
            options={{ title: 'Student Registration' }}
          />
          <Stack.Screen
            name="Review"
            component={ReviewScreen}
            options={{ title: 'Review Details' }}
          />
          <Stack.Screen
            name="Success"
            component={SuccessScreen}
            // No back arrow and no swipe-back on the final screen.
            options={{ title: 'Registered', headerBackVisible: false, gestureEnabled: false }}
          />
        </Stack.Navigator>
      </NavigationContainer>
    </SafeAreaProvider>
  );
}
