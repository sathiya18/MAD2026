# Student Registration — React Native (Expo) Demo

Three screens: **Registration form → Review → Success (ID card)**.

## Files
```
App.js                         Navigation stack (React Navigation, native-stack)
index.js                       Registers App with Expo
app.json                       Expo app config
src/theme.js                   Shared colours
src/validation.js              Form validation (pure JS)
src/components/StepHeader.js   Reusable "Step X of 3" header
src/components/FormInput.js    Labelled TextInput with error text
src/screens/RegistrationScreen.js  Screen 1 – Form (useState)
src/screens/ReviewScreen.js        Screen 2 – Summary, Edit / Submit
src/screens/SuccessScreen.js       Screen 3 – Confirmation + ID card
```

## How to run
Requires Node.js 18+ (20 LTS recommended).

```bash
cd rn_student_registration
npm install
npx expo start
```

Then either:
- install **Expo Go** on an Android phone/iPhone and scan the QR code, or
- press `a` to open an Android emulator (Android Studio must be installed).

Tip for class: edit a colour in `src/theme.js` and save — **Fast Refresh**
updates the phone instantly while keeping the typed form values.

Built for Expo SDK 57 (React Native 0.86, React 19) with React Navigation 7.
The Expo Go app on the phone must support SDK 57 — update it from the Play Store / App Store.
