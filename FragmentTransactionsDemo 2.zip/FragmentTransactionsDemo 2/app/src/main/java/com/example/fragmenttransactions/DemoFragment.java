package com.example.fragmenttransactions;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.concurrent.atomic.AtomicInteger;

/**
 * The single "test subject" fragment every transaction button in
 * MainActivity operates on. It carries its own incrementing instance
 * number so Replace's "destroys the old one, creates a genuinely new one"
 * behaviour is provable on screen — Add and Attach reuse/redisplay the
 * SAME number, Replace always shows a NEW number.
 */
public class DemoFragment extends LoggingFragment {

    private static final AtomicInteger INSTANCE_COUNTER = new AtomicInteger(0);

    private final int instanceId = INSTANCE_COUNTER.incrementAndGet();

    /** Human-readable identity used in both the on-screen event log and Logcat. */
    public String label() {
        return "DemoFragment#" + instanceId;
    }

    @Override
    protected String logTag() {
        return label();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_demo, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        TextView tvInstance = view.findViewById(R.id.tvInstance);
        tvInstance.setText("#" + instanceId);
    }
}
