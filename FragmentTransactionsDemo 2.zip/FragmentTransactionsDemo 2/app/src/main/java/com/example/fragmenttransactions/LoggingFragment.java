package com.example.fragmenttransactions;

import android.os.Bundle;
import android.util.Log;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;

/**
 * Logs every lifecycle callback to Logcat, tagged with this instance's own
 * label (see DemoFragment.label()). Pair this with the on-screen event log
 * in MainActivity: the event log shows what you clicked and why; Logcat
 * (filter by "DemoFragment") shows exactly which lifecycle callbacks that
 * click actually triggered — useful for connecting Slide 17's transaction
 * types back to Slide 16's lifecycle chain.
 */
public abstract class LoggingFragment extends Fragment {

    /** Subclasses override this to identify themselves in Logcat, e.g. "DemoFragment#3". */
    protected String logTag() {
        return getClass().getSimpleName();
    }

    @Override
    public void onAttach(@NonNull android.content.Context context) {
        super.onAttach(context);
        Log.d(logTag(), "onAttach()");
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(logTag(), "onCreate()");
    }

    @Override
    public void onViewCreated(@NonNull View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        Log.d(logTag(), "onViewCreated()");
    }

    @Override
    public void onStart() {
        super.onStart();
        Log.d(logTag(), "onStart()");
    }

    @Override
    public void onResume() {
        super.onResume();
        Log.d(logTag(), "onResume()");
    }

    @Override
    public void onPause() {
        Log.d(logTag(), "onPause()");
        super.onPause();
    }

    @Override
    public void onStop() {
        Log.d(logTag(), "onStop()");
        super.onStop();
    }

    @Override
    public void onDestroyView() {
        Log.d(logTag(), "onDestroyView()");
        super.onDestroyView();
    }

    @Override
    public void onDestroy() {
        Log.d(logTag(), "onDestroy()");
        super.onDestroy();
    }

    @Override
    public void onDetach() {
        Log.d(logTag(), "onDetach()");
        super.onDetach();
    }
}
