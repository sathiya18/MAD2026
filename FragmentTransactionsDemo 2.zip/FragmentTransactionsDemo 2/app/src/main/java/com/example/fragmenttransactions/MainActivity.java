package com.example.fragmenttransactions;

import android.os.Bundle;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;

/**
 * Recreates Slide 17 ("Fragments Transactions") as a working demo: one
 * DemoFragment plus seven buttons — Add, Remove, Replace, Attach, Detach,
 * Show, Hide — each performing exactly the FragmentTransaction call it's
 * named after, with the resulting state reflected both in the on-screen
 * "stage" and in a running event log (Slides 18-21's own wording).
 *
 * Only buttons that are valid FROM THE CURRENT STATE are enabled — e.g.
 * you can't Attach a fragment that isn't currently Detached. That gating
 * is itself part of the lesson: it shows students which transitions are
 * legal from which state, matching the seven operations to four states:
 *   NONE -> (Add / Replace) -> SHOWING
 *   SHOWING -> (Hide) -> HIDDEN -> (Show) -> SHOWING
 *   SHOWING/HIDDEN -> (Detach) -> DETACHED -> (Attach) -> SHOWING
 *   any state -> (Remove) -> NONE
 *   any state -> (Replace) -> SHOWING (new instance)
 *
 * Note: this is a simplified state machine for teaching clarity. The real
 * FragmentManager allows a few more combinations than are exposed here.
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "demo";

    private enum FragState { NONE, SHOWING, HIDDEN, DETACHED }

    private FragmentManager fm;
    private DemoFragment currentFragment;
    private FragState state = FragState.NONE;

    private TextView tvStatus;
    private TextView tvLog;
    private ScrollView logScroll;

    private Button btnAdd, btnRemove, btnReplace, btnDetach, btnAttach, btnHide, btnShow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        fm = getSupportFragmentManager();

        tvStatus = findViewById(R.id.tvStatus);
        tvLog = findViewById(R.id.tvLog);
        logScroll = findViewById(R.id.logScroll);

        btnAdd = findViewById(R.id.btnAdd);
        btnRemove = findViewById(R.id.btnRemove);
        btnReplace = findViewById(R.id.btnReplace);
        btnDetach = findViewById(R.id.btnDetach);
        btnAttach = findViewById(R.id.btnAttach);
        btnHide = findViewById(R.id.btnHide);
        btnShow = findViewById(R.id.btnShow);

        // Recover state after a rotation: the FragmentManager already kept
        // the fragment alive, so ask IT what state it's really in instead
        // of assuming NONE.
        currentFragment = (DemoFragment) fm.findFragmentByTag(TAG);
        if (currentFragment == null) {
            state = FragState.NONE;
        } else if (currentFragment.isDetached()) {
            state = FragState.DETACHED;
        } else if (currentFragment.isHidden()) {
            state = FragState.HIDDEN;
        } else {
            state = FragState.SHOWING;
        }

        btnAdd.setOnClickListener(v -> {
            currentFragment = new DemoFragment();
            fm.beginTransaction().add(R.id.container, currentFragment, TAG).commit();
            state = FragState.SHOWING;
            log("Add: created " + currentFragment.label() + " — the Fragment is added to the container layout.");
            refresh();
        });

        btnRemove.setOnClickListener(v -> {
            String who = currentFragment.label();
            fm.beginTransaction().remove(currentFragment).commit();
            log("Remove: got the reference to " + who + " and removed it — the fragment is destroyed and detached from the host activity.");
            currentFragment = null;
            state = FragState.NONE;
            refresh();
        });

        btnReplace.setOnClickListener(v -> {
            String old = (currentFragment != null) ? currentFragment.label() : "(nothing was in the container)";
            currentFragment = new DemoFragment();
            fm.beginTransaction().replace(R.id.container, currentFragment, TAG).commit();
            log("Replace: " + old + " destroyed (if present); " + currentFragment.label()
                    + " added fresh — a genuinely NEW instance, not the old one redisplayed.");
            state = FragState.SHOWING;
            refresh();
        });

        btnDetach.setOnClickListener(v -> {
            fm.beginTransaction().detach(currentFragment).commit();
            log("Detach: " + currentFragment.label() + "'s view is destroyed and detached from the Activity UI — "
                    + "the object itself is still present, just not visible.");
            state = FragState.DETACHED;
            refresh();
        });

        btnAttach.setOnClickListener(v -> {
            fm.beginTransaction().attach(currentFragment).commit();
            log("Attach: " + currentFragment.label() + "'s view is recreated — re-attached to the activity and visible.");
            state = FragState.SHOWING;
            refresh();
        });

        btnHide.setOnClickListener(v -> {
            fm.beginTransaction().hide(currentFragment).commit();
            log("Hide: " + currentFragment.label() + "'s view becomes invisible, but it continues to be in the RESUMED state — nothing is destroyed.");
            state = FragState.HIDDEN;
            refresh();
        });

        btnShow.setOnClickListener(v -> {
            fm.beginTransaction().show(currentFragment).commit();
            log("Show: " + currentFragment.label() + "'s view is visible again, remaining in the RESUMED state as before.");
            state = FragState.SHOWING;
            refresh();
        });

        refresh();
    }

    /** Enable only the buttons that are a legal transition from the current state, and update the status banner. */
    private void refresh() {
        boolean none = state == FragState.NONE;
        boolean showing = state == FragState.SHOWING;
        boolean hidden = state == FragState.HIDDEN;
        boolean detached = state == FragState.DETACHED;

        btnAdd.setEnabled(none);
        btnReplace.setEnabled(true); // Replace works from any state — it just makes sure a fresh fragment ends up showing
        btnRemove.setEnabled(!none);
        btnDetach.setEnabled(showing || hidden);
        btnAttach.setEnabled(detached);
        btnHide.setEnabled(showing);
        btnShow.setEnabled(hidden);

        String label = (currentFragment != null) ? currentFragment.label() : "";
        int color;
        String text;
        switch (state) {
            case SHOWING:
                color = ContextCompat.getColor(this, R.color.status_showing);
                text = "Status: SHOWING (" + label + ") — visible, fully RESUMED";
                break;
            case HIDDEN:
                color = ContextCompat.getColor(this, R.color.status_hidden);
                text = "Status: HIDDEN (" + label + ") — invisible, still RESUMED, nothing destroyed";
                break;
            case DETACHED:
                color = ContextCompat.getColor(this, R.color.status_detached);
                text = "Status: DETACHED (" + label + ") — view destroyed, object retained by the FragmentManager";
                break;
            default:
                color = ContextCompat.getColor(this, R.color.status_none);
                text = "Status: NONE — no fragment currently added";
        }
        tvStatus.setBackgroundColor(color);
        tvStatus.setText(text);
    }

    private void log(String message) {
        tvLog.append(message + "\n\n");
        logScroll.post(() -> logScroll.fullScroll(android.view.View.FOCUS_DOWN));
    }
}
