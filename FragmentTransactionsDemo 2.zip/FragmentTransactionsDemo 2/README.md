# Fragment Transactions Demo — classroom project

Recreates Slide 17 ("Fragments Transactions") as a working app: one `DemoFragment`
and seven buttons — **Add, Remove, Replace, Attach, Detach, Show, Hide** — each
button performs exactly the `FragmentTransaction` call it's named after, live.

## How to open it

Same as the other demo: Android Studio → **Open** → select this folder, let it
resolve the Gradle wrapper (or create a new Empty Views Activity project and copy
these `.java`/`.xml` files in, matching the paths below).

## What to demo in class

1. **Add** — creates `DemoFragment#1` and drops it into the stage. Status banner
   turns green ("SHOWING"). Ties to Slide 18.
2. **Hide → Show** — the fragment's box disappears/reappears, but watch Logcat
   (filter by `DemoFragment#1`): **no lifecycle callbacks fire at all** during
   Hide/Show. Nothing is destroyed — this is the cheapest of the seven operations,
   exactly as Slide 21 says.
3. **Detach → Attach** — the box disappears (view destroyed: `onDestroyView()`
   fires in Logcat), but the status banner shows the object is still tracked
   ("DETACHED"). Attach fires `onCreateView()`/`onViewCreated()` again — a new
   *view*, same fragment *object*. Ties to Slide 20.
4. **Remove** — the box disappears and the status banner goes back to grey
   ("NONE"). Logcat shows the full teardown: `onDestroyView()` → `onDestroy()` →
   `onDetach()`. The object is gone, not just hidden. Ties to Slide 18.
5. **Replace** — tap Add first, note the instance number (e.g. `#1`), then tap
   Replace. The new box shows `#2` — a genuinely new `DemoFragment` instance was
   created, not the old one reused. This is the detail students most often miss:
   Replace = destroy whatever was there + add fresh, not "update in place."

The on-screen **event log** at the bottom prints the same wording as Slides 18-21
every time you tap a button, so the concept and the on-screen effect land at the
same moment — no need to have Logcat open, though it's there for the deeper dive.

Only buttons that are a *legal* transition from the current state are enabled
(e.g. you can't tap Attach unless something is currently Detached) — greyed-out
buttons are themselves a teaching point about which operations make sense from
which state.

## Project layout

```
app/src/main/java/com/example/fragmenttransactions/
  MainActivity.java     - the 4-state machine (NONE/SHOWING/HIDDEN/DETACHED)
                           and all seven button handlers
  DemoFragment.java      - the fragment under test; carries an instance counter
                           so Replace's "new object" claim is provable on screen
  LoggingFragment.java   - base class that Log.d()'s every lifecycle callback
app/src/main/res/layout/
  activity_main.xml      - status banner, stage container, event log, 7 buttons
  fragment_demo.xml       - the colored box shown inside the stage
```
