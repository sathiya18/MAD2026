# Services Demo — Types of Services (Scheduled / Started / Bound)

A single-screen Android project that runs all three service types from the
"Types of Services" slide **at the same time, side by side**, so their
differences show up as observable behaviour instead of just diagram arrows.

```
Job Scheduler API  --launch-->  ScheduledJobService   (Scheduled Service)
Android Component  --start -->  StartedService        (Started Service)
Android Component  --binds -->  BoundService           (Bound Service)
```

## Project layout

```
app/src/main/java/cse/pec/sathiya/servicesdemo/
    MainActivity.java          UI + wiring for all three demos
    StartedService.java        Type 2 — Started Service (foreground, counts up)
    BoundService.java          Type 3 — Bound Service (two-way method calls)
    ScheduledJobService.java   Type 1 — Scheduled Service (via JobScheduler)
    EventLog.java              Shared timestamped logger used by all four
app/src/main/res/layout/activity_main.xml   one screen, three sections + a live event log
app/src/main/AndroidManifest.xml            declares all three services + required permissions
```

Open the project root folder in Android Studio (File → Open) and let it
sync Gradle; it targets `compileSdk 34` / `minSdk 24` and uses only
AndroidX + Material + `androidx.localbroadcastmanager` as dependencies, no
special setup needed. On first run, Android 13+ devices will prompt for the
notification permission — that's expected (see **Started Service**, below).

## How each type is implemented, and how to see it working

### 1. Scheduled Service — `ScheduledJobService` + `JobScheduler`

MainActivity never calls this class directly. Tapping **Schedule Job**
builds a `JobInfo` (job id 42, `setMinimumLatency(5000)`,
`setOverrideDeadline(15000)`) and hands it to the system's `JobScheduler`.
The **system**, not your app, decides exactly when to instantiate
`ScheduledJobService` and call `onStartJob()` — somewhere between 5 and 15
seconds later here.

*(A real periodic job — `setPeriodic(...)` — enforces a 15-minute minimum
interval on real devices, which isn't practical to watch live in a lab
session, so this demo uses a one-shot deferred job instead. The concept —
"the system decides when to run it, independent of any component being
alive" — is the same one either way.)*

**To see what makes this type distinctive:** tap **Schedule Job**, then
immediately background the app (Home button) or even force-stop it from
Android Settings → Apps → Services Demo → Force stop. Reopen the app after
~15 seconds and check the Event Log / "Runs so far" counter — it will have
incremented even though nothing in your app was running to trigger it. That
is the one thing neither a Started nor a Bound Service can do on their own.

### 2. Started Service — `StartedService`

Tapping **Start Service** calls `ContextCompat.startForegroundService()`.
Once started, `StartedService` runs on its own timeline — a `Handler`
ticks a counter once a second — completely independent of MainActivity. It
keeps counting if you rotate the device, if you press Home and come back,
or even if MainActivity is destroyed and recreated. It only stops when you
tap **Stop Service**, which sends it `ACTION_STOP` and it calls
`stopSelf()`.

It's built as a **foreground service** (`startForeground()` + a persistent,
low-priority notification showing the live counter) because on modern
Android a plain background service gets killed within seconds once the app
leaves the foreground — a foreground service is the only way to actually
observe "runs independently of the caller" rather than just read about it.
That's also why the manifest declares `FOREGROUND_SERVICE` /
`FOREGROUND_SERVICE_DATA_SYNC` and the app requests `POST_NOTIFICATIONS` at
startup (required from Android 13 onward).

**To see what makes this type distinctive:** start it, then rotate the
device or leave the app entirely (Home button) — the notification keeps
counting up on its own. Compare this with the Bound Service below, which
dies the moment nothing is bound to it anymore.

### 3. Bound Service — `BoundService`

Tapping **Bind Service** calls `bindService(..., BIND_AUTO_CREATE)`. Unlike
`startService()`, this returns a live `Binder` (`BoundService.LocalBinder`)
that MainActivity holds onto (`boundServiceRef`). The **Add via Service**
button then calls `boundServiceRef.add(a, b)` directly — a normal Java
method call that runs inside the service and returns a real value straight
back to the caller. That's genuine two-way, synchronous communication,
which a Started Service's fire-and-forget `startService()` simply cannot
offer.

Bind lifetime is tied to how many clients are bound: tap **Unbind
Service** and watch the Event Log show `onUnbind()` immediately followed by
`onDestroy()` — nobody had to explicitly "stop" it, unlike the Started
Service.

**To see what makes this type distinctive:** tap **Bind Service**, enter
two numbers, tap **Add via Service** a few times (the call count is
tracked service-side), then **Unbind Service** — the service disappears
entirely, with no lingering process to stop.

## The shared Event Log

Every lifecycle callback (`onCreate`, `onStartCommand`, `onBind`,
`onUnbind`, `onStartJob`, `jobFinished`, …) across all three services and
MainActivity is written through one small helper, `EventLog.log()`, which:

1. Prints to Logcat under the tag `ServicesDemo` (filter Logcat by that tag
   to watch everything in one place, including — for the Scheduled
   Service — logs that appear even after the app process was relaunched
   by the system).
2. Persists to `SharedPreferences`, so the on-screen **Event Log** section
   still shows the full history the next time you open the app, even if the
   process was killed in between.
3. Broadcasts locally so the Event Log view refreshes immediately whenever
   the app is in the foreground.

This is what makes it possible to prove the Scheduled Service ran even
while your app's process didn't exist — the log entry is written by
`ScheduledJobService` itself, independent of MainActivity, and is simply
waiting in `SharedPreferences` the next time you look.

## Suggested demo / lab sequence

1. Tap **Schedule Job**, then immediately press Home. Wait ~15 seconds,
   reopen the app, and check the Event Log for the `onStartJob` /
   `jobFinished` lines and the incremented run count.
2. Tap **Start Service**, then rotate the device (or leave and return) and
   watch the counter keep incrementing without you having done anything.
   Tap **Stop Service** and confirm the counter stops and the notification
   disappears.
3. Tap **Bind Service**, run a couple of additions, then **Unbind Service**
   and see `onDestroy()` fire immediately in the Event Log — contrast this
   with the Started Service, which needed an explicit Stop.
4. Scroll through the Event Log as a class and match each line back to
   which of the three arrows in the original diagram (Job Scheduler API →
   Service, Android Component → Service (start), Android Component →
   Service (bind)) produced it.
