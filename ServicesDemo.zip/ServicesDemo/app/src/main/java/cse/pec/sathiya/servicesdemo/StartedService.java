package cse.pec.sathiya.servicesdemo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.core.app.NotificationCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * TYPE 2 in the slide: "Started Service".
 *
 * Started from an Android Component (MainActivity) via
 * ContextCompat.startForegroundService(). Once started it runs
 * independently of whoever started it — it keeps counting even if
 * MainActivity is destroyed, rotated, or backgrounded. It only stops when
 * it calls stopSelf() itself, or something sends it the ACTION_STOP intent.
 *
 * It is implemented as a FOREGROUND service (startForeground() + a
 * persistent notification) because on modern Android a plain background
 * service started while the app is in the background gets killed almost
 * immediately — a foreground service is the only reliable way to actually
 * SEE a Started Service keep running independently, which is the whole
 * point of this demo.
 */
public class StartedService extends Service {

    public static final String ACTION_STOP =
            "cse.pec.sathiya.servicesdemo.action.STOP_STARTED_SERVICE";
    public static final String ACTION_TICK =
            "cse.pec.sathiya.servicesdemo.action.STARTED_SERVICE_TICK";
    public static final String EXTRA_COUNT = "count";

    private static final String CHANNEL_ID = "started_service_channel";
    private static final int NOTIFICATION_ID = 1001;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private int counter = 0;
    private boolean running = false;

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            counter++;
            EventLog.log(StartedService.this, "StartedService", "tick, counter=" + counter);
            updateNotification();
            broadcastTick();
            if (running) {
                handler.postDelayed(this, 1000);
            }
        }
    };

    @Override
    public void onCreate() {
        super.onCreate();
        createNotificationChannel();
        EventLog.log(this, "StartedService", "onCreate");
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            EventLog.log(this, "StartedService", "received ACTION_STOP, shutting down");
            stopTicking();
            stopForeground(true);
            stopSelf();
            return START_NOT_STICKY;
        }

        EventLog.log(this, "StartedService", "onStartCommand — entering foreground, starting counter");
        startForeground(NOTIFICATION_ID, buildNotification());
        if (!running) {
            running = true;
            handler.post(ticker);
        }
        // START_STICKY: if the system kills this service to reclaim memory,
        // recreate it and call onStartCommand(null,...) again — appropriate
        // for an ongoing task like this counter, as opposed to a one-shot
        // command that shouldn't be silently replayed.
        return START_STICKY;
    }

    @Override
    public IBinder onBind(Intent intent) {
        // This service is only ever started, never bound — returning null
        // here is correct and expected for a pure Started Service.
        return null;
    }

    @Override
    public void onDestroy() {
        EventLog.log(this, "StartedService", "onDestroy, final counter=" + counter);
        stopTicking();
        super.onDestroy();
    }

    private void stopTicking() {
        running = false;
        handler.removeCallbacks(ticker);
    }

    private void broadcastTick() {
        Intent i = new Intent(ACTION_TICK);
        i.putExtra(EXTRA_COUNT, counter);
        LocalBroadcastManager.getInstance(this).sendBroadcast(i);
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Started Service", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Shows the Started Service demo is running");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) {
                nm.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildNotification() {
        Intent stopIntent = new Intent(this, StartedService.class);
        stopIntent.setAction(ACTION_STOP);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT
                | (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S ? PendingIntent.FLAG_IMMUTABLE : 0);
        PendingIntent stopPendingIntent = PendingIntent.getService(this, 0, stopIntent, flags);

        return new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("Started Service running")
                .setContentText("Counter: " + counter + " (keeps counting even if you leave the app)")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setOngoing(true)
                .addAction(android.R.drawable.ic_media_pause, "Stop", stopPendingIntent)
                .build();
    }

    private void updateNotification() {
        NotificationManager nm = getSystemService(NotificationManager.class);
        if (nm != null) {
            nm.notify(NOTIFICATION_ID, buildNotification());
        }
    }
}
