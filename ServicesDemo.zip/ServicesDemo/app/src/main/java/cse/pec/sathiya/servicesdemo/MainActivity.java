package cse.pec.sathiya.servicesdemo;

import android.Manifest;
import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.IBinder;
import android.text.TextUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

/**
 * Single-screen demo that exercises all three service types from the
 * "Types of Services" slide, side by side, so the difference in behaviour
 * is directly observable instead of just described:
 *
 *   1. Scheduled Service — MainActivity hands a JobInfo to JobScheduler;
 *      the SYSTEM decides when to actually run ScheduledJobService.
 *   2. Started Service   — MainActivity calls startForegroundService();
 *      StartedService then runs independently until it stops itself.
 *   3. Bound Service     — MainActivity calls bindService() and gets a
 *      live Binder back, enabling direct two-way method calls.
 *
 * See the Event Log section on screen (and Logcat, tag "ServicesDemo") for
 * a timestamped trace of every lifecycle callback as you press each button.
 */
public class MainActivity extends AppCompatActivity {

    private static final int JOB_ID = 42;
    private static final int REQUEST_POST_NOTIFICATIONS = 100;

    private TextView tvStartedStatus;

    private BoundService boundServiceRef;
    private boolean isBound = false;
    private TextView tvBoundStatus;
    private EditText etNumA, etNumB;
    private TextView tvBoundResult;

    private TextView tvJobStatus;

    private TextView tvEventLog;

    private final BroadcastReceiver updatesReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (StartedService.ACTION_TICK.equals(intent.getAction())) {
                int count = intent.getIntExtra(StartedService.EXTRA_COUNT, 0);
                tvStartedStatus.setText("Running — counter = " + count);
            }
            refreshEventLog();
        }
    };

    private final ServiceConnection boundConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            BoundService.LocalBinder binder = (BoundService.LocalBinder) service;
            boundServiceRef = binder.getService();
            isBound = true;
            tvBoundStatus.setText("Bound ✓  " + boundServiceRef.getStatus());
            refreshEventLog();
        }

        @Override
        public void onServiceDisconnected(ComponentName name) {
            isBound = false;
            boundServiceRef = null;
            tvBoundStatus.setText("Disconnected (service process crashed?)");
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        bindViews();
        wireStartedServiceButtons();
        wireBoundServiceButtons();
        wireScheduledServiceButtons();

        maybeRequestNotificationPermission();
        EventLog.log(this, "MainActivity", "onCreate");
        refreshEventLog();
    }

    private void bindViews() {
        tvStartedStatus = findViewById(R.id.tvStartedStatus);
        tvBoundStatus = findViewById(R.id.tvBoundStatus);
        etNumA = findViewById(R.id.etNumA);
        etNumB = findViewById(R.id.etNumB);
        tvBoundResult = findViewById(R.id.tvBoundResult);
        tvJobStatus = findViewById(R.id.tvJobStatus);
        tvEventLog = findViewById(R.id.tvEventLog);
    }

    // ---------------- Started Service ----------------

    private void wireStartedServiceButtons() {
        Button btnStart = findViewById(R.id.btnStartStarted);
        Button btnStop = findViewById(R.id.btnStopStarted);

        btnStart.setOnClickListener(v -> {
            Intent intent = new Intent(this, StartedService.class);
            ContextCompat.startForegroundService(this, intent);
            tvStartedStatus.setText("Start requested…");
            EventLog.log(this, "MainActivity", "startForegroundService(StartedService)");
        });

        btnStop.setOnClickListener(v -> {
            Intent intent = new Intent(this, StartedService.class);
            intent.setAction(StartedService.ACTION_STOP);
            startService(intent);
            tvStartedStatus.setText("Stop requested…");
            EventLog.log(this, "MainActivity", "sent ACTION_STOP to StartedService");
        });
    }

    // ---------------- Bound Service ----------------

    private void wireBoundServiceButtons() {
        Button btnBind = findViewById(R.id.btnBind);
        Button btnUnbind = findViewById(R.id.btnUnbind);
        Button btnAdd = findViewById(R.id.btnAdd);

        btnBind.setOnClickListener(v -> {
            if (isBound) {
                Toast.makeText(this, "Already bound", Toast.LENGTH_SHORT).show();
                return;
            }
            Intent intent = new Intent(this, BoundService.class);
            bindService(intent, boundConnection, Context.BIND_AUTO_CREATE);
            EventLog.log(this, "MainActivity", "bindService(BoundService)");
        });

        btnUnbind.setOnClickListener(v -> {
            if (!isBound) {
                Toast.makeText(this, "Not currently bound", Toast.LENGTH_SHORT).show();
                return;
            }
            unbindService(boundConnection);
            isBound = false;
            boundServiceRef = null;
            tvBoundStatus.setText("Unbound");
            EventLog.log(this, "MainActivity", "unbindService(BoundService)");
        });

        btnAdd.setOnClickListener(v -> {
            if (!isBound || boundServiceRef == null) {
                Toast.makeText(this, "Bind the service first", Toast.LENGTH_SHORT).show();
                return;
            }
            int a = parseOrZero(etNumA);
            int b = parseOrZero(etNumB);
            // Direct, synchronous method call on the service instance — the
            // "two-way" communication a Bound Service uniquely provides.
            int result = boundServiceRef.add(a, b);
            tvBoundResult.setText("Result: " + a + " + " + b + " = " + result);
            refreshEventLog();
        });
    }

    private int parseOrZero(EditText et) {
        String s = et.getText().toString().trim();
        if (TextUtils.isEmpty(s)) return 0;
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    // ---------------- Scheduled Service (JobScheduler) ----------------

    private void wireScheduledServiceButtons() {
        Button btnSchedule = findViewById(R.id.btnScheduleJob);
        Button btnCancel = findViewById(R.id.btnCancelJob);

        btnSchedule.setOnClickListener(v -> scheduleDemoJob());

        btnCancel.setOnClickListener(v -> {
            JobScheduler scheduler = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
            scheduler.cancel(JOB_ID);
            tvJobStatus.setText("Job cancelled");
            EventLog.log(this, "MainActivity", "JobScheduler.cancel(JOB_ID)");
        });
    }

    private void scheduleDemoJob() {
        ComponentName component = new ComponentName(this, ScheduledJobService.class);
        JobInfo jobInfo = new JobInfo.Builder(JOB_ID, component)
                // Demo-friendly delay: a real PERIODIC job enforces a
                // 15-minute minimum interval, which isn't practical to
                // watch live in a lab session — so this schedules a
                // one-shot job the system is free to run any time between
                // 5 and 15 seconds from now, which is enough to try
                // backgrounding or force-stopping the app in between.
                .setMinimumLatency(5000)
                .setOverrideDeadline(15000)
                .setPersisted(false)
                .build();

        JobScheduler scheduler = (JobScheduler) getSystemService(Context.JOB_SCHEDULER_SERVICE);
        int result = scheduler.schedule(jobInfo);
        if (result == JobScheduler.RESULT_SUCCESS) {
            tvJobStatus.setText("Job scheduled — will run within 5–15s. Runs so far: "
                    + ScheduledJobService.getRunCount(this));
            EventLog.log(this, "MainActivity",
                    "JobScheduler.schedule() succeeded — try backgrounding or force-stopping the app now");
        } else {
            tvJobStatus.setText("Failed to schedule job");
        }
    }

    private void maybeRequestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.POST_NOTIFICATIONS},
                        REQUEST_POST_NOTIFICATIONS);
            }
        }
    }

    // ---------------- Shared log + lifecycle ----------------

    private void refreshEventLog() {
        tvEventLog.setText(EventLog.getLog(this));
        tvJobStatus.setText("Runs so far: " + ScheduledJobService.getRunCount(this));
    }

    @Override
    protected void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(
                updatesReceiver, new IntentFilter(StartedService.ACTION_TICK));
        LocalBroadcastManager.getInstance(this).registerReceiver(
                updatesReceiver, new IntentFilter(EventLog.ACTION_LOG_UPDATED));
        refreshEventLog();
    }

    @Override
    protected void onPause() {
        super.onPause();
        LocalBroadcastManager.getInstance(this).unregisterReceiver(updatesReceiver);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (isBound) {
            unbindService(boundConnection);
            isBound = false;
        }
    }
}
