package cse.pec.sathiya.servicesdemo;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

/**
 * TYPE 3 in the slide: "Bound Service".
 *
 * An Android Component (MainActivity) binds to this service with
 * bindService(). Binding hands the client a live Binder object it can call
 * methods on directly and get a return value back — genuine two-way
 * communication, unlike a Started Service, which the caller can only
 * fire-and-forget via startService(). This service exists only as long as
 * at least one client is bound to it (with BIND_AUTO_CREATE); when the last
 * client unbinds, onUnbind() and then onDestroy() are called automatically
 * — nobody has to remember to "stop" it.
 */
public class BoundService extends Service {

    /** Local (same-process) binder — just hands back the Service instance. */
    public class LocalBinder extends Binder {
        BoundService getService() {
            return BoundService.this;
        }
    }

    private final IBinder binder = new LocalBinder();
    private int callCount = 0;

    @Override
    public void onCreate() {
        super.onCreate();
        EventLog.log(this, "BoundService", "onCreate (created because a client bound to it)");
    }

    @Override
    public IBinder onBind(Intent intent) {
        EventLog.log(this, "BoundService", "onBind — client connected, handing over the Binder");
        return binder;
    }

    @Override
    public boolean onUnbind(Intent intent) {
        EventLog.log(this, "BoundService", "onUnbind — last client disconnected");
        // false: don't call onRebind() on the next bind, just call onBind()
        // again as normal.
        return false;
    }

    @Override
    public void onDestroy() {
        EventLog.log(this, "BoundService", "onDestroy, total calls served=" + callCount);
        super.onDestroy();
    }

    /**
     * The actual "two-way" API the bound client calls directly and
     * synchronously — this is exactly what a Started Service cannot offer,
     * since startService() has no way to hand a result back to the caller.
     */
    public int add(int a, int b) {
        callCount++;
        int result = a + b;
        EventLog.log(this, "BoundService",
                "add(" + a + ", " + b + ") = " + result + "  [call #" + callCount + "]");
        return result;
    }

    public String getStatus() {
        return "BoundService alive, served " + callCount + " call(s) so far";
    }
}
