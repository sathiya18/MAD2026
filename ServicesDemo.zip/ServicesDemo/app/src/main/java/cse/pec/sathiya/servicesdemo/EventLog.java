package cse.pec.sathiya.servicesdemo;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.util.Log;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 * A tiny shared logger used by all three services and MainActivity so every
 * lifecycle event is:
 *   (a) printed to Logcat under the tag "ServicesDemo",
 *   (b) persisted to SharedPreferences so it survives process death and
 *       Activity recreation (important for proving the Scheduled Service
 *       really did run even after the app process was killed), and
 *   (c) broadcast live to MainActivity so the on-screen log updates
 *       immediately if the app happens to be in the foreground.
 */
public class EventLog {

    private static final String TAG = "ServicesDemo";
    private static final String PREFS = "services_demo_log";
    private static final String KEY_LOG = "log_text";
    public static final String ACTION_LOG_UPDATED =
            "cse.pec.sathiya.servicesdemo.LOG_UPDATED";
    private static final int MAX_CHARS = 6000;

    private static final SimpleDateFormat TIME_FORMAT =
            new SimpleDateFormat("HH:mm:ss", Locale.getDefault());

    public static synchronized void log(Context context, String tag, String message) {
        String line = "[" + TIME_FORMAT.format(new Date()) + "] " + tag + ": " + message;
        Log.d(TAG, line);

        Context appContext = context.getApplicationContext();
        SharedPreferences prefs = appContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        String existing = prefs.getString(KEY_LOG, "");
        String updated = existing.isEmpty() ? line : existing + "\n" + line;
        if (updated.length() > MAX_CHARS) {
            updated = updated.substring(updated.length() - MAX_CHARS);
        }
        prefs.edit().putString(KEY_LOG, updated).apply();

        Intent broadcast = new Intent(ACTION_LOG_UPDATED);
        LocalBroadcastManager.getInstance(appContext).sendBroadcast(broadcast);
    }

    public static String getLog(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return prefs.getString(KEY_LOG, "(no events yet — try one of the buttons above)");
    }

    public static void clear(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        prefs.edit().remove(KEY_LOG).apply();
        Intent broadcast = new Intent(ACTION_LOG_UPDATED);
        LocalBroadcastManager.getInstance(context.getApplicationContext()).sendBroadcast(broadcast);
    }
}
