package cse.pec.sathiya.servicesdemo;

import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Context;
import android.content.SharedPreferences;

/**
 * TYPE 1 in the slide: "Scheduled Service".
 *
 * Nothing in this app calls this class directly — MainActivity only hands a
 * JobInfo to the system JobScheduler (see MainActivity.scheduleDemoJob() /
 * the "Schedule Job" button). The OS decides when to actually launch this
 * JobService, based on the delay/constraints in that JobInfo (and, for real
 * periodic jobs, battery state and device-idle windows).
 *
 * Crucially, the system will start this even if the app's process has been
 * killed in the meantime: schedule the job, then immediately force-stop the
 * app (or swipe it away from Recents) and watch it still run and log an
 * event a few seconds later — that's the defining feature of a Scheduled
 * Service versus the other two types, which both need a live component to
 * start or bind them.
 */
public class ScheduledJobService extends JobService {

    private static final String PREFS = "services_demo_log";
    private static final String KEY_JOB_RUN_COUNT = "job_run_count";

    @Override
    public boolean onStartJob(JobParameters params) {
        EventLog.log(this, "ScheduledJobService", "onStartJob — system launched us to run the job");

        // onStartJob() runs on the main thread, so real work belongs on a
        // background thread; we call jobFinished() when it's done.
        new Thread(() -> {
            try {
                Thread.sleep(1000); // pretend to do some work
            } catch (InterruptedException ignored) {
            }

            SharedPreferences prefs = getApplicationContext()
                    .getSharedPreferences(PREFS, MODE_PRIVATE);
            int runCount = prefs.getInt(KEY_JOB_RUN_COUNT, 0) + 1;
            prefs.edit().putInt(KEY_JOB_RUN_COUNT, runCount).apply();

            EventLog.log(ScheduledJobService.this, "ScheduledJobService",
                    "work complete, this is run #" + runCount + " — calling jobFinished()");

            // false = the job does not need to be rescheduled/retried.
            jobFinished(params, false);
        }).start();

        // true = there IS asynchronous work happening (the thread above);
        // tells the system not to treat the job as finished until
        // jobFinished() is actually called.
        return true;
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        EventLog.log(this, "ScheduledJobService",
                "onStopJob — system cancelled us before we finished");
        // true = please reschedule this job to try again later.
        return true;
    }

    public static int getRunCount(Context context) {
        SharedPreferences prefs = context.getApplicationContext()
                .getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        return prefs.getInt(KEY_JOB_RUN_COUNT, 0);
    }
}
