package com.example.fragmenttoactivitycomm;

/**
 * The contract Fragment A uses to hand data up to whichever Activity is
 * hosting it. The Fragment never talks to MainActivity directly — it only
 * knows about this interface, which is what keeps the Fragment reusable
 * inside any Activity that is willing to implement it.
 */
public interface MyListener {
    void add(int num1, int num2);
}
