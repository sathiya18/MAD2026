package com.example.fragmenttoactivitycomm;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

/**
 * Recreates the slide exactly: MainActivity implements MyListener and
 * provides the one method Fragment A calls (add). Everything Fragment A
 * knows about its host is this interface — MainActivity is free to do
 * whatever it wants with the numbers once they arrive, in this case just
 * showing the sum in the yellow "Result" banner.
 */
public class MainActivity extends AppCompatActivity implements MyListener {

    private TextView txvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txvResult = findViewById(R.id.txvResult);

        if (savedInstanceState == null) {
            FragmentManager fm = getSupportFragmentManager();
            FragmentTransaction ft = fm.beginTransaction();
            ft.add(R.id.fragment_container, new FragmentA());
            ft.commit();
        }
    }

    @Override
    public void add(int num1, int num2) {
        int result = num1 + num2;
        txvResult.setText("Result : " + result);
    }
}
