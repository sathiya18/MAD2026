package com.example.fragmenttoactivitycomm;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * Recreates the slide's "Sending data to an Activity from a Fragment"
 * example. Fragment A collects two numbers from the user and, instead of
 * reaching into MainActivity directly (which would break re-use — this
 * Fragment would only ever work inside MainActivity), it calls a method on
 * the MyListener interface. Whatever Activity is hosting it at the time is
 * responsible for actually implementing that method.
 */
public class FragmentA extends Fragment {

    private MyListener listener;
    private EditText etNum1;
    private EditText etNum2;

    /**
     * onAttach fires as soon as the Fragment is attached to its host
     * Activity — this is the standard place to grab and validate the
     * listener, matching the interface pattern taught on the slide, but
     * done a bit more defensively: getActivity() inside onCreateView can
     * be null, onAttach's context argument cannot.
     */
    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof MyListener) {
            listener = (MyListener) context;
        } else {
            // Fails fast with a clear message instead of a mysterious
            // ClassCastException the first time sendData() runs.
            throw new ClassCastException(context + " must implement MyListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_a, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        etNum1 = view.findViewById(R.id.etNum1);
        etNum2 = view.findViewById(R.id.etNum2);
        Button btnSend = view.findViewById(R.id.btnSend);

        btnSend.setOnClickListener(v -> sendData());
    }

    /** Reads the two EditTexts and hands the numbers to the host Activity through MyListener. */
    private void sendData() {
        int num1;
        int num2;
        try {
            num1 = Integer.parseInt(etNum1.getText().toString().trim());
            num2 = Integer.parseInt(etNum2.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), "Enter two whole numbers first.", Toast.LENGTH_SHORT).show();
            return;
        }
        // Fragment A never touches MainActivity's TextView — it only calls
        // the interface method. MainActivity decides what "add" means.
        listener.add(num1, num2);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
