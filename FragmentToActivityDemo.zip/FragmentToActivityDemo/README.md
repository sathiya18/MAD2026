# Fragment → Activity Communication Demo

Recreates the slide ("Sending data to an Activity from a Fragment") exactly: an
interface (`MyListener`), a Fragment that calls it, and an Activity that
implements it. Same yellow "Result" banner over a cyan Fragment area as the
screenshot.

## How to open it

Android Studio → **Open** → select this folder → let Gradle sync (this
project ships its own Gradle wrapper, so it does not depend on whatever
Gradle version happens to be installed locally).

## What to demo in class

1. Type two numbers into Fragment A's boxes (defaults to 23 and 17, matching
   the slide) and tap **SEND DATA TO PARENT ACTIVITY**.
2. The yellow banner at the top updates to `Result : <sum>` — MainActivity
   computed that, not the Fragment.
3. The teaching point: `FragmentA.java` never imports or references
   `MainActivity` anywhere. It only knows about `MyListener`. Point students
   at `sendData()` — it casts `getActivity()`/the attach `Context` to
   `MyListener`, not to `MainActivity`. That's what makes Fragment A reusable
   inside *any* Activity willing to implement the interface, not just this
   one.
4. `onAttach()` is where the cast happens, not `onCreateView()` — worth
   contrasting with the slide's simplified version, which does the cast
   inside `sendData()` itself. Doing it in `onAttach()` means a
   misconfigured host Activity fails immediately and loudly (a clear
   `ClassCastException` message naming `MyListener`) instead of only
   crashing the first time the button is tapped.

## Project layout

```
app/src/main/java/com/example/fragmenttoactivitycomm/
  MyListener.java   - the interface contract: void add(int num1, int num2)
  FragmentA.java     - collects two numbers, calls listener.add() on click
  MainActivity.java  - implements MyListener, updates the Result banner
app/src/main/res/layout/
  activity_main.xml  - app bar, yellow Result banner, cyan fragment_container
  fragment_a.xml     - "Fragment A" label, two number fields, send button
```
