// screens/success_screen.dart
// SCREEN 3 — confirmation and a digital ID card.
// CONCEPTS: Container + BoxDecoration (gradients, rounded corners),
// CircleAvatar, PopScope (controlling the system back button),
// clearing the navigation stack to start over.

import 'package:flutter/material.dart';

import '../main.dart';
import '../models/student.dart';
import '../widgets/step_header.dart';

class SuccessScreen extends StatelessWidget {
  final Student student;

  const SuccessScreen({super.key, required this.student});

  void _registerAnother(BuildContext context) {
    // Clear everything and open a fresh, empty form.
    Navigator.pushNamedAndRemoveUntil(
      context,
      StudentRegistrationApp.registerRoute,
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    final initials = student.fullName
        .split(' ')
        .where((p) => p.isNotEmpty)
        .take(2)
        .map((p) => p[0].toUpperCase())
        .join();

    // PopScope: when the user presses the system Back button here,
    // send them to a fresh form instead of closing the app.
    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _registerAnother(context);
      },
      child: Scaffold(
        appBar: AppBar(
          title: const Text('Registered'),
          automaticallyImplyLeading: false, // no back arrow
        ),
        body: SafeArea(
          child: ListView(
            padding: const EdgeInsets.all(20),
            children: [
              const StepHeader(currentStep: 3, title: 'Registration complete'),
              Icon(Icons.check_circle, color: Colors.green.shade600, size: 80),
              const SizedBox(height: 12),
              Text(
                'Welcome, ${student.fullName.split(' ').first}!',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.titleLarge,
              ),
              const SizedBox(height: 4),
              const Text(
                'Your registration was submitted successfully.',
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),

              // --- Digital ID card ---
              Container(
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(16),
                  gradient: LinearGradient(
                    colors: [colors.primary, colors.tertiary],
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                  ),
                ),
                child: Row(
                  children: [
                    CircleAvatar(
                      radius: 32,
                      backgroundColor: Colors.white,
                      child: Text(initials,
                          style: TextStyle(
                              fontSize: 22,
                              fontWeight: FontWeight.bold,
                              color: colors.primary)),
                    ),
                    const SizedBox(width: 16),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(student.fullName,
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontSize: 18,
                                  fontWeight: FontWeight.bold)),
                          const SizedBox(height: 4),
                          Text(student.registerNumber,
                              style: const TextStyle(color: Colors.white70)),
                          Text('${student.department} · ${student.year}',
                              style: const TextStyle(color: Colors.white70)),
                          const SizedBox(height: 8),
                          Text('ID: ${student.registrationId}',
                              style: const TextStyle(
                                  color: Colors.white,
                                  fontWeight: FontWeight.w600,
                                  letterSpacing: 1)),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 32),
              FilledButton.icon(
                onPressed: () => _registerAnother(context),
                icon: const Icon(Icons.person_add_alt),
                label: const Text('Register Another Student'),
                style: FilledButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
