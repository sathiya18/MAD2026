// screens/review_screen.dart
// SCREEN 2 — shows what the student entered, before submitting.
// CONCEPTS: receiving data through the constructor, StatelessWidget,
// Card/ListTile, Navigator.pop vs pushReplacementNamed vs
// pushNamedAndRemoveUntil, async/await with a loading dialog.

import 'dart:math';

import 'package:flutter/material.dart';

import '../main.dart';
import '../models/student.dart';
import '../widgets/step_header.dart';

class ReviewScreen extends StatelessWidget {
  final Student student; // passed in from Screen 1

  const ReviewScreen({super.key, required this.student});

  Future<void> _submit(BuildContext context) async {
    // Show a loading dialog to simulate a network call to a server.
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (_) => const Center(child: CircularProgressIndicator()),
    );

    await Future.delayed(const Duration(seconds: 2)); // pretend API call

    if (!context.mounted) return; // screen may have closed while waiting
    Navigator.pop(context); // close the dialog

    // Generate a simple registration ID, e.g. REG-2026-4821
    final id = 'REG-${DateTime.now().year}-${1000 + Random().nextInt(9000)}';
    final submitted = student.copyWith(registrationId: id);

    // Go to Screen 3 and REMOVE all earlier screens from the stack,
    // so the system Back button cannot return to the submitted form.
    Navigator.pushNamedAndRemoveUntil(
      context,
      StudentRegistrationApp.successRoute,
      (route) => false,
      arguments: submitted,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Review Details')),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(20),
          children: [
            const StepHeader(currentStep: 2, title: 'Check before submitting'),
            Card(
              child: Column(
                children: [
                  _row(Icons.person_outline, 'Full Name', student.fullName),
                  _row(Icons.badge_outlined, 'Register No.', student.registerNumber),
                  _row(Icons.email_outlined, 'Email', student.email),
                  _row(Icons.phone_outlined, 'Phone', '+91 ${student.phone}'),
                  _row(Icons.school_outlined, 'Department', student.department),
                  _row(Icons.calendar_today_outlined, 'Year', student.year),
                  _row(Icons.wc_outlined, 'Gender', student.gender),
                ],
              ),
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: () => _submit(context),
              icon: const Icon(Icons.check),
              label: const Text('Confirm & Submit'),
              style: FilledButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              // Replace this screen with a pre-filled form (keeps the data).
              onPressed: () => Navigator.pushReplacementNamed(
                context,
                StudentRegistrationApp.registerRoute,
                arguments: student,
              ),
              icon: const Icon(Icons.edit_outlined),
              label: const Text('Back to Edit'),
              style: OutlinedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // A private helper method that builds one row of the summary card.
  Widget _row(IconData icon, String label, String value) {
    return ListTile(
      leading: Icon(icon),
      title: Text(label, style: const TextStyle(fontSize: 13, color: Colors.grey)),
      subtitle: Text(value,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600)),
    );
  }
}
