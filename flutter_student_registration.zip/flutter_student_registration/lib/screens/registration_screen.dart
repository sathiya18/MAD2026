// screens/registration_screen.dart
// SCREEN 1 — the registration form.
// CONCEPTS: StatefulWidget + State, setState(), Form + GlobalKey<FormState>,
// TextFormField + validator, TextEditingController, DropdownButtonFormField,
// ChoiceChip, RadioListTile, Navigator.pushNamed with arguments, dispose().

import 'package:flutter/material.dart';

import '../main.dart';
import '../models/student.dart';
import '../widgets/step_header.dart';

class RegistrationScreen extends StatefulWidget {
  /// Optional: when the user taps "Edit" on the Review screen, we pre-fill.
  final Student? initialStudent;

  const RegistrationScreen({super.key, this.initialStudent});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  // The key lets us call validate() on every field inside the Form at once.
  final _formKey = GlobalKey<FormState>();

  // Controllers hold the text typed into each TextFormField.
  final _nameController = TextEditingController();
  final _regNoController = TextEditingController();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();

  // Values for the non-text inputs. Changing them needs setState().
  String? _department;
  String _year = '1st Year';
  String _gender = 'Female';

  static const _departments = [
    'Computer Science',
    'Information Technology',
    'Electronics & Communication',
    'Electrical & Electronics',
    'Mechanical',
    'Civil',
  ];
  static const _years = ['1st Year', '2nd Year', '3rd Year', '4th Year'];
  static const _genders = ['Female', 'Male', 'Other'];

  @override
  void initState() {
    super.initState();
    // initState runs once when the screen is created — perfect for pre-filling.
    final s = widget.initialStudent;
    if (s != null) {
      _nameController.text = s.fullName;
      _regNoController.text = s.registerNumber;
      _emailController.text = s.email;
      _phoneController.text = s.phone;
      _department = s.department;
      _year = s.year;
      _gender = s.gender;
    }
  }

  @override
  void dispose() {
    // Controllers use resources; always release them when the screen closes.
    _nameController.dispose();
    _regNoController.dispose();
    _emailController.dispose();
    _phoneController.dispose();
    super.dispose();
  }

  void _goToReview() {
    // validate() runs every field's validator and shows the error messages.
    if (!_formKey.currentState!.validate()) return;

    final student = Student(
      fullName: _nameController.text.trim(),
      registerNumber: _regNoController.text.trim().toUpperCase(),
      email: _emailController.text.trim(),
      phone: _phoneController.text.trim(),
      department: _department!,
      year: _year,
      gender: _gender,
    );

    // Move to screen 2, passing the Student object as "arguments".
    Navigator.pushNamed(
      context,
      StudentRegistrationApp.reviewRoute,
      arguments: student,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Student Registration')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(20),
          child: Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                const StepHeader(currentStep: 1, title: 'Enter your details'),

                TextFormField(
                  controller: _nameController,
                  decoration: const InputDecoration(
                    labelText: 'Full Name',
                    prefixIcon: Icon(Icons.person_outline),
                  ),
                  textCapitalization: TextCapitalization.words,
                  validator: (value) {
                    if (value == null || value.trim().isEmpty) {
                      return 'Please enter your name';
                    }
                    if (value.trim().length < 3) {
                      return 'Name must have at least 3 letters';
                    }
                    return null; // null means "valid"
                  },
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _regNoController,
                  decoration: const InputDecoration(
                    labelText: 'Register Number',
                    hintText: 'e.g. 21CS1045',
                    prefixIcon: Icon(Icons.badge_outlined),
                  ),
                  textCapitalization: TextCapitalization.characters,
                  validator: (value) =>
                      (value == null || value.trim().length < 6)
                          ? 'Enter a valid register number (min 6 characters)'
                          : null,
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _emailController,
                  decoration: const InputDecoration(
                    labelText: 'Email',
                    prefixIcon: Icon(Icons.email_outlined),
                  ),
                  keyboardType: TextInputType.emailAddress,
                  validator: (value) {
                    final pattern = RegExp(r'^[\w.+-]+@[\w-]+\.[\w.]+$');
                    if (value == null || !pattern.hasMatch(value.trim())) {
                      return 'Enter a valid email address';
                    }
                    return null;
                  },
                ),
                const SizedBox(height: 16),

                TextFormField(
                  controller: _phoneController,
                  decoration: const InputDecoration(
                    labelText: 'Phone Number',
                    prefixText: '+91 ',
                    prefixIcon: Icon(Icons.phone_outlined),
                  ),
                  keyboardType: TextInputType.phone,
                  maxLength: 10,
                  validator: (value) =>
                      (value == null || !RegExp(r'^[6-9]\d{9}$').hasMatch(value))
                          ? 'Enter a valid 10-digit mobile number'
                          : null,
                ),
                const SizedBox(height: 8),

                DropdownButtonFormField<String>(
                  value: _department,
                  decoration: const InputDecoration(
                    labelText: 'Department',
                    prefixIcon: Icon(Icons.school_outlined),
                  ),
                  items: _departments
                      .map((d) => DropdownMenuItem(value: d, child: Text(d)))
                      .toList(),
                  onChanged: (value) => setState(() => _department = value),
                  validator: (value) =>
                      value == null ? 'Please choose a department' : null,
                ),
                const SizedBox(height: 20),

                Text('Year of Study',
                    style: Theme.of(context).textTheme.titleSmall),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 8,
                  children: _years.map((y) {
                    return ChoiceChip(
                      label: Text(y),
                      selected: _year == y,
                      // setState() tells Flutter to rebuild with the new value.
                      onSelected: (_) => setState(() => _year = y),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 20),

                Text('Gender', style: Theme.of(context).textTheme.titleSmall),
                ..._genders.map((g) => RadioListTile<String>(
                      title: Text(g),
                      value: g,
                      groupValue: _gender,
                      contentPadding: EdgeInsets.zero,
                      onChanged: (value) => setState(() => _gender = value!),
                    )),
                const SizedBox(height: 20),

                FilledButton.icon(
                  onPressed: _goToReview,
                  icon: const Icon(Icons.arrow_forward),
                  label: const Text('Review Details'),
                  style: FilledButton.styleFrom(
                    padding: const EdgeInsets.symmetric(vertical: 16),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
