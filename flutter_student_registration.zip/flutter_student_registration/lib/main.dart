// main.dart
// Entry point of the Flutter app.
// CONCEPTS: runApp(), MaterialApp, ThemeData, named routes, onGenerateRoute.

import 'package:flutter/material.dart';

import 'models/student.dart';
import 'screens/registration_screen.dart';
import 'screens/review_screen.dart';
import 'screens/success_screen.dart';

void main() {
  // runApp() takes the root widget and attaches it to the screen.
  runApp(const StudentRegistrationApp());
}

/// The root widget. It is a StatelessWidget because the app shell itself
/// never changes — only the screens inside it do.
class StudentRegistrationApp extends StatelessWidget {
  const StudentRegistrationApp({super.key});

  // Route names kept in one place so screens don't mistype them.
  static const String registerRoute = '/';
  static const String reviewRoute = '/review';
  static const String successRoute = '/success';

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Student Registration',
      debugShowCheckedModeBanner: false,

      // One theme for the whole app: every screen picks up these colours.
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF3F51B5)),
        useMaterial3: true,
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
          filled: true,
        ),
      ),

      initialRoute: registerRoute,

      // onGenerateRoute lets us read the "arguments" passed with
      // Navigator.pushNamed() and hand them to the next screen's constructor.
      onGenerateRoute: (RouteSettings settings) {
        switch (settings.name) {
          case registerRoute:
            // When coming back from Review with "Edit", a Student may be passed.
            final student = settings.arguments as Student?;
            return MaterialPageRoute(
              builder: (_) => RegistrationScreen(initialStudent: student),
              settings: settings,
            );
          case reviewRoute:
            final student = settings.arguments as Student;
            return MaterialPageRoute(
              builder: (_) => ReviewScreen(student: student),
              settings: settings,
            );
          case successRoute:
            final student = settings.arguments as Student;
            return MaterialPageRoute(
              builder: (_) => SuccessScreen(student: student),
              settings: settings,
            );
          default:
            return MaterialPageRoute(
              builder: (_) => const Scaffold(
                body: Center(child: Text('Page not found')),
              ),
            );
        }
      },
    );
  }
}
