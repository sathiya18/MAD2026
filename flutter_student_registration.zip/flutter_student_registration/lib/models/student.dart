// models/student.dart
// A plain Dart class (a "model") that carries the form data between screens.
// CONCEPTS: classes, final fields, named constructor parameters, copyWith.

class Student {
  final String fullName;
  final String registerNumber;
  final String email;
  final String phone;
  final String department;
  final String year;
  final String gender;
  final String? registrationId; // filled in only after submission

  const Student({
    required this.fullName,
    required this.registerNumber,
    required this.email,
    required this.phone,
    required this.department,
    required this.year,
    required this.gender,
    this.registrationId,
  });

  /// Returns a new Student with some fields changed.
  /// Objects are immutable (all fields are final), so we copy instead of edit.
  Student copyWith({String? registrationId}) {
    return Student(
      fullName: fullName,
      registerNumber: registerNumber,
      email: email,
      phone: phone,
      department: department,
      year: year,
      gender: gender,
      registrationId: registrationId ?? this.registrationId,
    );
  }
}
