// widgets/step_header.dart
// A small reusable widget shown at the top of every screen: "Step 1 of 3".
// CONCEPTS: custom StatelessWidget, constructor parameters, Row/Expanded.

import 'package:flutter/material.dart';

class StepHeader extends StatelessWidget {
  final int currentStep; // 1, 2 or 3
  final String title;

  const StepHeader({super.key, required this.currentStep, required this.title});

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('Step $currentStep of 3',
            style: TextStyle(color: colors.primary, fontWeight: FontWeight.w600)),
        const SizedBox(height: 4),
        Text(title, style: Theme.of(context).textTheme.headlineSmall),
        const SizedBox(height: 12),
        // Three progress bars; the ones up to currentStep are coloured.
        Row(
          children: List.generate(3, (index) {
            final done = index < currentStep;
            return Expanded(
              child: Container(
                height: 6,
                margin: const EdgeInsets.only(right: 6),
                decoration: BoxDecoration(
                  color: done ? colors.primary : colors.surfaceContainerHighest,
                  borderRadius: BorderRadius.circular(3),
                ),
              ),
            );
          }),
        ),
        const SizedBox(height: 20),
      ],
    );
  }
}
