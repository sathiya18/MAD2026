# CPDemo1 — Content Provider demo (Nation / countries)

This is the Content Provider counterpart to the StudentDB SQLite demo,
built from the same slide deck (`Android_ContentProvider_and_SQLite_1.pptx`,
slides 11–26). Same CRUD idea, same `SQLiteOpenHelper` pattern underneath —
but this time nothing outside the `data` package is allowed to touch the
database directly. Everything goes through a `ContentProvider`.

## How to open it

1. Android Studio → **File → Open** → select the `CPDemo1` folder.
2. If Android Studio reports the Gradle wrapper is missing, let it create
   one (it will offer to do this automatically), or use whatever Gradle
   version you already have installed via **File → Sync Project with
   Gradle Files**.
3. Run on an emulator or device (`minSdk 21`).

## Project map — slide → file

| Slide(s) | Concept | File |
|---|---|---|
| 18 | Contract class (table name, column names, URIs) | `data/NationContract.java` |
| 18 | Database Helper class | `data/NationDbHelper.java` |
| 22, 23 | ContentProvider subclass — `onCreate`, `query`, `insert`, `update`, `delete`, `getType` | `data/NationProvider.java` |
| 19 | `query()` using projection / selection / selectionArgs / sortOrder | `NationProvider.query()`, `MainActivity.loadCountries()` |
| 24 | Content URI format `content://<authority>/path_name` | `NationContract.AUTHORITY`, `CONTENT_URI` |
| 25, 26 | URI patterns with `UriMatcher` (`countries`, `countries/#`) | `NationProvider` static block |
| 22 | Declaring the provider in the manifest | `AndroidManifest.xml` (`<provider>`) |
| 13, 14 | "Other apps can't touch your data directly — go through the CP" | `MainActivity` never imports `NationDbHelper` or `SQLiteDatabase` — only `ContentResolver` |

## What's actually being demonstrated

`MainActivity` is written as a *client* of the provider, not as part of it.
Every button (Add / Update / Delete) and the list refresh call
`getContentResolver().insert()/update()/delete()/query()` — never the
database directly. That's the one line that matters: if you comment out the
`<provider>` tag in the manifest, those `ContentResolver` calls throw
immediately, even though the SQLite file and `NationDbHelper` are untouched.
The provider isn't a convenience wrapper here — it's the *only* door in.

The provider currently ships with `android:exported="false"`, so right now
only components inside this same app can use it. To prove a genuinely
separate process can reach it exactly the same way, flip that to `"true"`
(this is the real-world default for a provider meant to be shared) and run,
straight from a terminal — no code of yours involved on that side at all:

```
adb shell content query --uri content://cse.pec.sathiya.cpdemo1.data.NationProvider/countries
adb shell content insert --uri content://cse.pec.sathiya.cpdemo1.data.NationProvider/countries --bind name:s:Nepal --bind capital:s:Kathmandu
adb shell content delete --uri content://cse.pec.sathiya.cpdemo1.data.NationProvider/countries/1
```

`adb shell content` is a generic tool that talks to *any* app's exported
provider by URI alone — it has no idea `countries` is a SQLite table, or
that `NationDbHelper` even exists. That's exactly the "ABC APP / XYZ APP"
picture from slide 14: a second, unrelated caller reaching your data purely
through the URI contract.

## Where the real SQLite file lives

Same as the StudentDB demo: `/data/data/cse.pec.sathiya.cpdemo1/databases/nation.db`
— view it with Android Studio's **Database Inspector** while the app is
running, or pull it with `adb shell run-as cse.pec.sathiya.cpdemo1 cat databases/nation.db`.
