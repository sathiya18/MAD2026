package cse.pec.sathiya.cpdemo1.data;

import android.net.Uri;
import android.provider.BaseColumns;

/**
 * Slide 18: "Define Contract class — Contains DB configuration constants,
 * Table name, Column names."
 *
 * This class holds no logic. It exists purely so that NationProvider,
 * NationDbHelper, and any client (MainActivity, another app, adb) all agree
 * on the same table name, column names, and URI — instead of each side
 * typing "countries" or "name" as a raw string and risking a typo.
 */
public final class NationContract {

    // Not instantiable — this is a bag of constants only.
    private NationContract() {}

    /**
     * Slide 24: "<authority> has to be unique — use app's package name with
     * class name." This exact string is also what AndroidManifest.xml
     * declares in <provider android:authorities="...">, and it MUST match
     * exactly or the provider will never be found.
     */
    public static final String AUTHORITY = "cse.pec.sathiya.cpdemo1.data.NationProvider";

    /** content://cse.pec.sathiya.cpdemo1.data.NationProvider */
    public static final Uri BASE_CONTENT_URI = Uri.parse("content://" + AUTHORITY);

    /** Slide 24: "Path_name — helps client app to reach our database table." */
    public static final String PATH_COUNTRIES = "countries";

    /**
     * Everything about the "countries" table lives inside this inner class.
     * Implementing BaseColumns gives us CountryEntry._ID for free — the
     * standard "_id" primary-key column every Cursor/ListAdapter expects.
     */
    public static final class CountryEntry implements BaseColumns {

        /** content://cse.pec.sathiya.cpdemo1.data.NationProvider/countries */
        public static final Uri CONTENT_URI =
                BASE_CONTENT_URI.buildUpon().appendPath(PATH_COUNTRIES).build();

        /** MIME type for a directory (list) of countries — returned by getType() for .../countries */
        public static final String CONTENT_LIST_TYPE =
                "vnd.android.cursor.dir/" + AUTHORITY + "." + PATH_COUNTRIES;

        /** MIME type for a single country row — returned by getType() for .../countries/# */
        public static final String CONTENT_ITEM_TYPE =
                "vnd.android.cursor.item/" + AUTHORITY + "." + PATH_COUNTRIES;

        public static final String TABLE_NAME = "countries";

        // _ID comes from BaseColumns ("_id")
        public static final String COLUMN_NAME = "name";
        public static final String COLUMN_CAPITAL = "capital";
    }
}
