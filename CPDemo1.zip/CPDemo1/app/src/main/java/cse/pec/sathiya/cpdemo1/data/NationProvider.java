package cse.pec.sathiya.cpdemo1.data;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.Context;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import cse.pec.sathiya.cpdemo1.data.NationContract.CountryEntry;

/**
 * Slide 22: "Create subclass of ContentProvider, override the abstract
 * methods, define Authority String / content URIs / column names, declare
 * ContentProvider inside manifest file."
 *
 * Slide 23 lists exactly the six methods below: onCreate, query, insert,
 * update, delete, getType. No client ever constructs this class with `new`
 * — the Android framework instantiates it once, automatically, the moment
 * something resolves a content:// URI whose authority matches the one
 * declared in the manifest.
 */
public class NationProvider extends ContentProvider {

    // ---- UriMatcher: turns an incoming Uri into an int code we can switch on ----
    // Slide 25/26 patterns:
    //   content://authority/countries      -> the whole table   (code COUNTRIES)
    //   content://authority/countries/#    -> one row, "#" = numeric id (code COUNTRY_ID)
    private static final int COUNTRIES = 100;
    private static final int COUNTRY_ID = 101;

    private static final UriMatcher sUriMatcher = new UriMatcher(UriMatcher.NO_MATCH);
    static {
        sUriMatcher.addURI(NationContract.AUTHORITY, NationContract.PATH_COUNTRIES, COUNTRIES);
        sUriMatcher.addURI(NationContract.AUTHORITY, NationContract.PATH_COUNTRIES + "/#", COUNTRY_ID);
    }

    private NationDbHelper dbHelper;

    /** Slide 23: "Called when application starts — use it to initialize ContentProvider." */
    @Override
    public boolean onCreate() {
        Context context = getContext();
        dbHelper = new NationDbHelper(context);
        return true;
    }

    /** Slide 23 / Slide 19: query() using projection, selection, selectionArgs, sortOrder. */
    @Nullable
    @Override
    public Cursor query(@NonNull Uri uri, @Nullable String[] projection, @Nullable String selection,
                         @Nullable String[] selectionArgs, @Nullable String sortOrder) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor;

        switch (sUriMatcher.match(uri)) {
            case COUNTRIES:
                // Whole table — whatever WHERE clause the caller passed in, if any.
                cursor = db.query(CountryEntry.TABLE_NAME, projection, selection,
                        selectionArgs, null, null, sortOrder);
                break;

            case COUNTRY_ID:
                // Single row — the id was embedded in the URI itself
                // (content://.../countries/7), so we build our own WHERE clause
                // and ignore whatever the caller passed for selection.
                selection = CountryEntry._ID + "=?";
                selectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};
                cursor = db.query(CountryEntry.TABLE_NAME, projection, selection,
                        selectionArgs, null, null, sortOrder);
                break;

            default:
                throw new IllegalArgumentException("Cannot query unknown URI: " + uri);
        }

        // So a CursorAdapter / CursorLoader (Slide 17) can auto-refresh when the data changes.
        cursor.setNotificationUri(getContext().getContentResolver(), uri);
        return cursor;
    }

    /** Slide 23: "getType — handle requests for the MIME type of the data for the given URI." */
    @Nullable
    @Override
    public String getType(@NonNull Uri uri) {
        switch (sUriMatcher.match(uri)) {
            case COUNTRIES:
                return CountryEntry.CONTENT_LIST_TYPE;
            case COUNTRY_ID:
                return CountryEntry.CONTENT_ITEM_TYPE;
            default:
                throw new IllegalArgumentException("Unknown URI: " + uri);
        }
    }

    /** Slide 23: "insert — insert data into database." Only the table-level URI makes sense here. */
    @Nullable
    @Override
    public Uri insert(@NonNull Uri uri, @Nullable ContentValues values) {
        if (sUriMatcher.match(uri) != COUNTRIES) {
            throw new IllegalArgumentException("Insert not supported for URI: " + uri);
        }
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        long newRowId = db.insert(CountryEntry.TABLE_NAME, null, values);
        if (newRowId == -1) {
            return null;
        }

        // Tell anyone watching this URI (e.g. a CursorLoader) that the data changed.
        getContext().getContentResolver().notifyChange(uri, null);

        // Hand back content://authority/countries/<newRowId>, the URI of the row just created.
        return ContentUris.withAppendedId(CountryEntry.CONTENT_URI, newRowId);
    }

    /** Slide 23: "update — update records." */
    @Override
    public int update(@NonNull Uri uri, @Nullable ContentValues values, @Nullable String selection,
                       @Nullable String[] selectionArgs) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rowsUpdated;

        switch (sUriMatcher.match(uri)) {
            case COUNTRIES:
                rowsUpdated = db.update(CountryEntry.TABLE_NAME, values, selection, selectionArgs);
                break;
            case COUNTRY_ID:
                selection = CountryEntry._ID + "=?";
                selectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};
                rowsUpdated = db.update(CountryEntry.TABLE_NAME, values, selection, selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Update not supported for URI: " + uri);
        }

        if (rowsUpdated != 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return rowsUpdated;
    }

    /** Slide 23: "delete — delete records." */
    @Override
    public int delete(@NonNull Uri uri, @Nullable String selection, @Nullable String[] selectionArgs) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        int rowsDeleted;

        switch (sUriMatcher.match(uri)) {
            case COUNTRIES:
                rowsDeleted = db.delete(CountryEntry.TABLE_NAME, selection, selectionArgs);
                break;
            case COUNTRY_ID:
                selection = CountryEntry._ID + "=?";
                selectionArgs = new String[]{String.valueOf(ContentUris.parseId(uri))};
                rowsDeleted = db.delete(CountryEntry.TABLE_NAME, selection, selectionArgs);
                break;
            default:
                throw new IllegalArgumentException("Delete not supported for URI: " + uri);
        }

        if (rowsDeleted != 0) {
            getContext().getContentResolver().notifyChange(uri, null);
        }
        return rowsDeleted;
    }
}
