package cse.pec.sathiya.cpdemo1;

import android.content.ContentUris;
import android.content.ContentValues;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

import cse.pec.sathiya.cpdemo1.data.NationContract.CountryEntry;

/**
 * This activity is deliberately written as the CLIENT of the Content Provider,
 * not as part of it. Notice what is never imported here: NationDbHelper,
 * SQLiteDatabase, SQLiteOpenHelper. This class only ever talks to
 * getContentResolver() — exactly the boundary Slide 13 describes ("Other
 * applications are not allowed to access the DS [directly]... CP has to be
 * used for other applications to access the DS").
 *
 * Even though the provider happens to live in the same app/APK here (so the
 * demo is self-contained and runnable), the code path is identical to what a
 * genuinely separate app would write to reach your data — that's the proof
 * the ContentProvider boundary is real, not just theoretical. You can see
 * this for yourself from a shell, acting as a true "other application":
 *
 *   adb shell content query --uri content://cse.pec.sathiya.cpdemo1.data.NationProvider/countries
 *
 * That command never touches your Java code or your SQLite file — it goes
 * through NationProvider exactly like MainActivity does below.
 */
public class MainActivity extends AppCompatActivity {

    private EditText etName, etCapital;
    private ArrayAdapter<String> adapter;

    // Parallel list: rowIds.get(position) is the _ID for adapter.getItem(position)
    private final List<Long> rowIds = new ArrayList<>();
    private long selectedId = -1; // -1 = nothing selected

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etCapital = findViewById(R.id.etCapital);
        ListView listView = findViewById(R.id.listView);

        Button btnAdd = findViewById(R.id.btnAdd);
        Button btnUpdate = findViewById(R.id.btnUpdate);
        Button btnDelete = findViewById(R.id.btnDelete);
        Button btnClear = findViewById(R.id.btnClear);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<>());
        listView.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> addCountry());
        btnUpdate.setOnClickListener(v -> updateCountry());
        btnDelete.setOnClickListener(v -> deleteCountry());
        btnClear.setOnClickListener(v -> clearForm());
        listView.setOnItemClickListener((parent, view, position, id) -> loadRowIntoForm(position));

        loadCountries();
    }

    // ---- INSERT: routed through ContentResolver -> NationProvider.insert() ----
    private void addCountry() {
        String name = etName.getText().toString().trim();
        String capital = etCapital.getText().toString().trim();
        if (name.isEmpty() || capital.isEmpty()) {
            Toast.makeText(this, "Enter name and capital", Toast.LENGTH_SHORT).show();
            return;
        }

        ContentValues values = new ContentValues();
        values.put(CountryEntry.COLUMN_NAME, name);
        values.put(CountryEntry.COLUMN_CAPITAL, capital);

        // getContentResolver().insert() looks up which provider owns this URI's
        // authority and hands the call off to it — MainActivity never sees a
        // SQLiteDatabase object at all.
        Uri newUri = getContentResolver().insert(CountryEntry.CONTENT_URI, values);
        Toast.makeText(this, newUri != null ? "Inserted: " + newUri : "Insert failed", Toast.LENGTH_SHORT).show();

        clearForm();
        loadCountries();
    }

    // ---- QUERY: same projection / selection / selectionArgs / sortOrder vocabulary as Slide 19 ----
    private void loadCountries() {
        String[] projection = {
                CountryEntry._ID,
                CountryEntry.COLUMN_NAME,
                CountryEntry.COLUMN_CAPITAL
        };

        Cursor cursor = getContentResolver().query(
                CountryEntry.CONTENT_URI,   // content://cse.pec.sathiya.cpdemo1.data.NationProvider/countries
                projection,
                null,                        // selection: no WHERE clause — fetch every row
                null,                        // selectionArgs
                CountryEntry.COLUMN_NAME + " ASC"); // sortOrder

        List<String> rows = new ArrayList<>();
        rowIds.clear();

        if (cursor != null) {
            while (cursor.moveToNext()) {
                long id = cursor.getLong(cursor.getColumnIndexOrThrow(CountryEntry._ID));
                String name = cursor.getString(cursor.getColumnIndexOrThrow(CountryEntry.COLUMN_NAME));
                String capital = cursor.getString(cursor.getColumnIndexOrThrow(CountryEntry.COLUMN_CAPITAL));
                rows.add(name + "  —  " + capital);
                rowIds.add(id);
            }
            cursor.close();
        }

        adapter.clear();
        adapter.addAll(rows);
        adapter.notifyDataSetChanged();
    }

    private void loadRowIntoForm(int position) {
        selectedId = rowIds.get(position);
        String[] parts = adapter.getItem(position).split(" {2}—{2}");
        if (parts.length == 2) {
            etName.setText(parts[0].trim());
            etCapital.setText(parts[1].trim());
        }
    }

    // ---- UPDATE: content://.../countries/<id>, matched by the "countries/#" UriMatcher pattern ----
    private void updateCountry() {
        if (selectedId == -1) {
            Toast.makeText(this, "Tap a row first", Toast.LENGTH_SHORT).show();
            return;
        }
        ContentValues values = new ContentValues();
        values.put(CountryEntry.COLUMN_NAME, etName.getText().toString().trim());
        values.put(CountryEntry.COLUMN_CAPITAL, etCapital.getText().toString().trim());

        Uri itemUri = ContentUris.withAppendedId(CountryEntry.CONTENT_URI, selectedId);
        int rows = getContentResolver().update(itemUri, values, null, null);
        Toast.makeText(this, rows + " row(s) updated", Toast.LENGTH_SHORT).show();

        clearForm();
        loadCountries();
    }

    // ---- DELETE ----
    private void deleteCountry() {
        if (selectedId == -1) {
            Toast.makeText(this, "Tap a row first", Toast.LENGTH_SHORT).show();
            return;
        }
        Uri itemUri = ContentUris.withAppendedId(CountryEntry.CONTENT_URI, selectedId);
        int rows = getContentResolver().delete(itemUri, null, null);
        Toast.makeText(this, rows + " row(s) deleted", Toast.LENGTH_SHORT).show();

        clearForm();
        loadCountries();
    }

    private void clearForm() {
        selectedId = -1;
        etName.setText("");
        etCapital.setText("");
    }
}
