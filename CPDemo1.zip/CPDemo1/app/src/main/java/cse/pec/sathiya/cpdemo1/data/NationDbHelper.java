package cse.pec.sathiya.cpdemo1.data;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import cse.pec.sathiya.cpdemo1.data.NationContract.CountryEntry;

/**
 * Slide 18: "Define Database Helper class — it helps to create database,
 * also manages database versions, performs DB operations."
 *
 * This is the exact same pattern as StudentDbHelper from the SQLite demo —
 * subclass SQLiteOpenHelper, override onCreate()/onUpgrade(). The only
 * difference this time is that NOTHING outside this package ever talks to
 * this class directly. NationProvider is the sole caller of
 * getReadableDatabase() / getWritableDatabase() — MainActivity never even
 * imports this file. That's the whole point of the Content Provider layer.
 */
public class NationDbHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "nation.db";
    private static final int DATABASE_VERSION = 1;

    public NationDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String SQL_CREATE_COUNTRIES_TABLE =
                "CREATE TABLE " + CountryEntry.TABLE_NAME + " (" +
                        CountryEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                        CountryEntry.COLUMN_NAME + " TEXT NOT NULL, " +
                        CountryEntry.COLUMN_CAPITAL + " TEXT NOT NULL);";
        db.execSQL(SQL_CREATE_COUNTRIES_TABLE);

        // Seed a couple of rows so the list isn't empty on first launch.
        db.execSQL("INSERT INTO " + CountryEntry.TABLE_NAME +
                " (" + CountryEntry.COLUMN_NAME + ", " + CountryEntry.COLUMN_CAPITAL + ") VALUES " +
                "('India', 'New Delhi'), ('Japan', 'Tokyo'), ('France', 'Paris');");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + CountryEntry.TABLE_NAME);
        onCreate(db);
    }
}
