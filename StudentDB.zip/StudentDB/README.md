# StudentDB — SQLite CRUD demo (Android, Java)

A minimal Android Studio project for demonstrating all five SQLite operations
live in class: **Create** (table), **Insert**, **Display** (Read), **Update**,
and **Delete** — matching the "SQLite Database" section of the accompanying
slide deck.

## Project structure

- `StudentDbHelper.java` — `SQLiteOpenHelper` subclass. `onCreate()` creates
  the `students` table (id, name, marks); `onUpgrade()` handles schema
  version bumps.
- `MainActivity.java` — one screen with two `EditText` fields (name, marks),
  four buttons (Add, Update, Delete, Clear) and a `ListView` that always
  reflects the current contents of the table.
- `activity_main.xml` — the layout for that screen.

## How to open

1. Open Android Studio → **Open** → select the `StudentDB` folder (the one
   containing this README and `settings.gradle`).
2. Let Gradle sync (Android Studio will fetch/rebuild the Gradle wrapper
   automatically if it's missing on your machine).
3. Run on an emulator or device (min SDK 21).

## Live demo script (maps to the CRUD slides)

1. **Insert** — type a name (e.g. "Arun") and marks (e.g. 78), tap **Add**.
   Point out `ContentValues` + `db.insert(...)` in `onAddClicked()`.
2. **Display** — the list below refreshes immediately after every operation
   via `refreshList()`, which runs `db.query(...)` and loops over the
   returned `Cursor` with `moveToNext()`. Add 2–3 more students to show the
   list growing.
3. **Update** — tap a row in the list (loads it into the two fields and
   remembers its `id`), change the marks, tap **Update**. Point out
   `db.update(...)` with a `WHERE id = ?` selection in `onUpdateClicked()`.
4. **Delete** — tap a row, tap **Delete**. Point out `db.delete(...)` with
   the same `WHERE id = ?` pattern in `onDeleteClicked()`.
5. **Clear** just resets the input fields and the current selection — it
   does not touch the database.

Tip: uninstalling and reinstalling the app (or clearing app data) resets the
database, since `student.db` is stored in the app's private storage — handy
if you want to start the demo from an empty table each class.
