package com.example.studentdb;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

/**
 * Live-demo Activity showing all five SQLite CRUD operations against a
 * "students" table: Create (table creation, in StudentDbHelper), Insert,
 * Display (Read), Update and Delete.
 *
 * Flow for the demo:
 *   1. Type a name + marks, tap "Add"        -> INSERT
 *   2. The list below refreshes automatically -> READ / DISPLAY
 *   3. Tap a row to load it into the fields, edit marks, tap "Update" -> UPDATE
 *   4. Tap a row, tap "Delete"                -> DELETE
 */
public class MainActivity extends AppCompatActivity {

    private StudentDbHelper dbHelper;

    private EditText etName;
    private EditText etMarks;
    private ListView lvStudents;

    private ArrayAdapter<String> adapter;
    private final List<String> displayList = new ArrayList<>();
    private final List<Long> studentIds = new ArrayList<>();

    // id of the row currently selected in the list (for Update / Delete), or null
    private Long selectedId = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new StudentDbHelper(this);

        etName = findViewById(R.id.etName);
        etMarks = findViewById(R.id.etMarks);
        lvStudents = findViewById(R.id.lvStudents);

        Button btnAdd = findViewById(R.id.btnAdd);
        Button btnUpdate = findViewById(R.id.btnUpdate);
        Button btnDelete = findViewById(R.id.btnDelete);
        Button btnClear = findViewById(R.id.btnClear);

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, displayList);
        lvStudents.setAdapter(adapter);

        btnAdd.setOnClickListener(this::onAddClicked);
        btnUpdate.setOnClickListener(this::onUpdateClicked);
        btnDelete.setOnClickListener(this::onDeleteClicked);
        btnClear.setOnClickListener(v -> clearFields());

        lvStudents.setOnItemClickListener((parent, view, position, id) -> onRowSelected(position));

        refreshList();
    }

    // ---------------------------------------------------------------
    // INSERT
    // ---------------------------------------------------------------
    private void onAddClicked(View v) {
        String name = etName.getText().toString().trim();
        String marksStr = etMarks.getText().toString().trim();

        if (name.isEmpty() || marksStr.isEmpty()) {
            Toast.makeText(this, "Enter both name and marks", Toast.LENGTH_SHORT).show();
            return;
        }

        int marks = Integer.parseInt(marksStr);

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(StudentDbHelper.COLUMN_NAME, name);
        values.put(StudentDbHelper.COLUMN_MARKS, marks);

        long newRowId = db.insert(StudentDbHelper.TABLE_STUDENTS, null, values);

        if (newRowId == -1) {
            Toast.makeText(this, "Insert failed", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Student added (id " + newRowId + ")", Toast.LENGTH_SHORT).show();
        }

        clearFields();
        refreshList();
    }

    // ---------------------------------------------------------------
    // READ / DISPLAY
    // ---------------------------------------------------------------
    private void refreshList() {
        studentIds.clear();
        displayList.clear();

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                StudentDbHelper.TABLE_STUDENTS,
                null,                               // all columns
                null, null,                         // no WHERE clause -> all rows
                null, null,
                StudentDbHelper.COLUMN_ID + " ASC"   // sort order
        );

        while (cursor.moveToNext()) {
            long id = cursor.getLong(cursor.getColumnIndexOrThrow(StudentDbHelper.COLUMN_ID));
            String name = cursor.getString(cursor.getColumnIndexOrThrow(StudentDbHelper.COLUMN_NAME));
            int marks = cursor.getInt(cursor.getColumnIndexOrThrow(StudentDbHelper.COLUMN_MARKS));

            studentIds.add(id);
            displayList.add("ID " + id + "   " + name + "   Marks: " + marks);
        }
        cursor.close();

        adapter.notifyDataSetChanged();
    }

    private void onRowSelected(int position) {
        selectedId = studentIds.get(position);

        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor = db.query(
                StudentDbHelper.TABLE_STUDENTS,
                null,
                StudentDbHelper.COLUMN_ID + " = ?",
                new String[]{String.valueOf(selectedId)},
                null, null, null
        );

        if (cursor.moveToFirst()) {
            String name = cursor.getString(cursor.getColumnIndexOrThrow(StudentDbHelper.COLUMN_NAME));
            int marks = cursor.getInt(cursor.getColumnIndexOrThrow(StudentDbHelper.COLUMN_MARKS));
            etName.setText(name);
            etMarks.setText(String.valueOf(marks));
        }
        cursor.close();

        Toast.makeText(this, "Selected row loaded — edit and tap Update, or tap Delete", Toast.LENGTH_SHORT).show();
    }

    // ---------------------------------------------------------------
    // UPDATE
    // ---------------------------------------------------------------
    private void onUpdateClicked(View v) {
        if (selectedId == null) {
            Toast.makeText(this, "Tap a student in the list first", Toast.LENGTH_SHORT).show();
            return;
        }

        String name = etName.getText().toString().trim();
        String marksStr = etMarks.getText().toString().trim();

        if (name.isEmpty() || marksStr.isEmpty()) {
            Toast.makeText(this, "Enter both name and marks", Toast.LENGTH_SHORT).show();
            return;
        }

        int marks = Integer.parseInt(marksStr);

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(StudentDbHelper.COLUMN_NAME, name);
        values.put(StudentDbHelper.COLUMN_MARKS, marks);

        String selection = StudentDbHelper.COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(selectedId) };

        int rows = db.update(StudentDbHelper.TABLE_STUDENTS, values, selection, selectionArgs);
        Toast.makeText(this, rows + " row(s) updated", Toast.LENGTH_SHORT).show();

        clearFields();
        refreshList();
    }

    // ---------------------------------------------------------------
    // DELETE
    // ---------------------------------------------------------------
    private void onDeleteClicked(View v) {
        if (selectedId == null) {
            Toast.makeText(this, "Tap a student in the list first", Toast.LENGTH_SHORT).show();
            return;
        }

        SQLiteDatabase db = dbHelper.getWritableDatabase();
        String selection = StudentDbHelper.COLUMN_ID + " = ?";
        String[] selectionArgs = { String.valueOf(selectedId) };

        int rows = db.delete(StudentDbHelper.TABLE_STUDENTS, selection, selectionArgs);
        Toast.makeText(this, rows + " row(s) deleted", Toast.LENGTH_SHORT).show();

        clearFields();
        refreshList();
    }

    // ---------------------------------------------------------------
    private void clearFields() {
        etName.setText("");
        etMarks.setText("");
        selectedId = null;
    }
}
