# Activity → Fragment Communication Demo

Recreates the slide ("Sending data to a Fragment from Activity") — demonstrates
**both** techniques the slide lists, not as two separate demos but as two
different moments of the same Fragment's life. Same yellow zone with two
number fields and a cyan Fragment A area as the screenshot.

## How to open it

Android Studio → **Open** → select this folder → let Gradle sync (this
project ships its own Gradle wrapper).

## What to demo in class

1. **App launches** — Fragment A already shows `Received: num1=1, num2=99`
   before you've tapped anything. That's Technique 1, **Using a Bundle
   Object**: `MainActivity.onCreate()` creates the Fragment with
   `FragmentA.newInstance(1, 99)`, which packs the numbers into a `Bundle`
   via `setArguments()` before the Fragment is even added. `FragmentA`
   reads them back in `onCreate()` via `getArguments()`.
2. Tap **ADD TWO NUMBERS** inside the cyan area — `Result : 100` appears.
   This runs entirely inside the Fragment; MainActivity is not involved.
3. Change the two numbers in the yellow boxes at the top and tap
   **SEND DATA TO FRAGMENT-A**. Watch the `Received: num1=..., num2=...`
   line update immediately — but `Result` does *not* change yet. That's
   Technique 2, **Using the Fragment Object**: MainActivity already holds a
   reference to the running `FragmentA` instance and calls
   `currentFragment.updateNumbers(num1, num2)` directly on it. A `Bundle`
   could not do this — arguments are fixed once a Fragment has been
   created, so any *later* update has to go through the object itself.
4. Tap **ADD TWO NUMBERS** again to see the new sum — a good moment to ask
   the class why the result didn't update automatically in step 3 (because
   `updateNumbers()` only stores the new numbers; nothing calls
   `setText()` on `tvResult` until the button is pressed).
5. Rotate the device. `MainActivity` recovers the *same* Fragment instance
   via `fm.findFragmentByTag(FRAGMENT_TAG)` instead of creating a new one
   with `newInstance()` again — worth pointing out, since re-creating it
   would silently reset whatever numbers Technique 2 had pushed in.

## Project layout

```
app/src/main/java/com/example/activitytofragmentcomm/
  FragmentA.java     - newInstance()/Bundle for startup data, updateNumbers()
                       for live updates, ADD TWO NUMBERS computes the sum
  MainActivity.java   - creates Fragment A with startup data, pushes new
                       data into the existing instance on button tap
app/src/main/res/layout/
  activity_main.xml   - app bar, yellow num1/num2 fields + send button,
                       cyan fragment_container
  fragment_a.xml      - "Fragment A" label, received-numbers line,
                       ADD TWO NUMBERS button, Result text
```
