package com.example.activitytofragmentcomm;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

/**
 * Recreates the slide exactly: MainActivity is the one sending data DOWN
 * into a Fragment, using both techniques the slide lists.
 *
 *  - On first launch it creates Fragment A with FragmentA.newInstance(1, 99)
 *    — the Bundle-object technique — so the Fragment already has starting
 *    values the moment it appears on screen.
 *  - Every time SEND DATA TO FRAGMENT-A is tapped afterwards, it calls
 *    currentFragment.updateNumbers(...) directly on the Fragment object it
 *    already holds a reference to — the second technique — which is the
 *    only way to get new data into a Fragment that's already running.
 */
public class MainActivity extends AppCompatActivity {

    private static final String FRAGMENT_TAG = "FragmentA";

    private EditText etNum1;
    private EditText etNum2;
    private FragmentA currentFragment;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNum1 = findViewById(R.id.etNum1);
        etNum2 = findViewById(R.id.etNum2);
        Button btnSend = findViewById(R.id.btnSend);

        FragmentManager fm = getSupportFragmentManager();
        if (savedInstanceState == null) {
            // Technique 1 — Bundle object: pass the starting numbers in at
            // creation time, before the Fragment exists to call a method on.
            currentFragment = FragmentA.newInstance(1, 99);
            FragmentTransaction ft = fm.beginTransaction();
            ft.add(R.id.fragment_container, currentFragment, FRAGMENT_TAG);
            ft.commit();
        } else {
            // After a rotation the FragmentManager already restored the
            // same Fragment instance — reuse it instead of creating a new one.
            currentFragment = (FragmentA) fm.findFragmentByTag(FRAGMENT_TAG);
        }

        btnSend.setOnClickListener(v -> sendDataToFragment());
    }

    private void sendDataToFragment() {
        int num1;
        int num2;
        try {
            num1 = Integer.parseInt(etNum1.getText().toString().trim());
            num2 = Integer.parseInt(etNum2.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Enter two whole numbers first.", Toast.LENGTH_SHORT).show();
            return;
        }
        // Technique 2 — Fragment object: the Fragment is already added and
        // running, so we call a public method on it directly. A Bundle
        // cannot do this — arguments are fixed once the Fragment is created.
        currentFragment.updateNumbers(num1, num2);
    }
}
