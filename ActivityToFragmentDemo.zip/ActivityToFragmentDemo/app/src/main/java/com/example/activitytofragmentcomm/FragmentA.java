package com.example.activitytofragmentcomm;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * Recreates the slide's "Sending data to a Fragment from an Activity" demo,
 * showing BOTH techniques the slide lists — not as two separate demos, but
 * as two different moments in this one fragment's life:
 *
 *  1. USING A BUNDLE OBJECT — how MainActivity hands this Fragment its
 *     starting numbers, via {@link #newInstance(int, int)} / setArguments()
 *     / getArguments(). This is the only option available before the
 *     Fragment exists yet — you cannot call a method on an object that
 *     hasn't been created.
 *
 *  2. USING THE FRAGMENT OBJECT DIRECTLY — how MainActivity pushes NEW
 *     numbers in later, once this Fragment is already added and running,
 *     by holding a reference to it and calling {@link #updateNumbers(int, int)}
 *     directly. A Bundle can't do this — arguments are read-only once the
 *     Fragment has been created.
 */
public class FragmentA extends Fragment {

    private static final String ARG_NUM1 = "arg_num1";
    private static final String ARG_NUM2 = "arg_num2";

    private int num1;
    private int num2;

    private TextView tvNums;
    private TextView tvResult;

    /** Technique 1: package the starting numbers into a Bundle before the Fragment exists. */
    public static FragmentA newInstance(int num1, int num2) {
        FragmentA fragment = new FragmentA();
        Bundle args = new Bundle();
        args.putInt(ARG_NUM1, num1);
        args.putInt(ARG_NUM2, num2);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Read the Bundle Technique 1 packed for us. getArguments() is null
        // if this Fragment was created with plain `new FragmentA()` instead
        // of newInstance(...), so default to 0 rather than crashing.
        Bundle args = getArguments();
        if (args != null) {
            num1 = args.getInt(ARG_NUM1, 0);
            num2 = args.getInt(ARG_NUM2, 0);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_a, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvNums = view.findViewById(R.id.tvNums);
        tvResult = view.findViewById(R.id.tvResult);
        Button btnAdd = view.findViewById(R.id.btnAdd);

        refreshNumsLabel();
        btnAdd.setOnClickListener(v -> tvResult.setText("Result : " + (num1 + num2)));
    }

    /**
     * Technique 2: MainActivity calls this directly on the live Fragment
     * instance to push in new numbers, any time after the Fragment has
     * already been added — no Bundle involved. tvResult is deliberately
     * left alone here: the whole teaching point of ADD TWO NUMBERS is that
     * new data arriving does not, by itself, recompute anything until the
     * user asks it to.
     */
    public void updateNumbers(int num1, int num2) {
        this.num1 = num1;
        this.num2 = num2;
        refreshNumsLabel();
    }

    private void refreshNumsLabel() {
        if (tvNums != null) {
            tvNums.setText("Received: num1=" + num1 + ", num2=" + num2);
        }
    }
}
