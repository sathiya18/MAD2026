# Fragment → Fragment Communication Demo

Recreates the "Sending data from one Fragment to another" slide and its
"Communication Between Two Fragments" diagram: two numbers travel from
Fragment A to Fragment B, but the two Fragments never reference each other
directly — MainActivity is the mediator, exactly matching the diagram's
note that this "creates a communication gap between two fragments" rather
than a direct link.

## How to open it

Android Studio → **Open** → select this folder → let Gradle sync (this
project ships its own Gradle wrapper).

## What to demo in class

This is deliberately split into two separate, visible taps — one per arrow
in the diagram:

1. Type two numbers into Fragment A (cyan box) and tap
   **SEND DATA TO PARENT ACTIVITY**. Fragment A calls `listener.add(x, y)`
   — it has no import, no reference, no knowledge of Fragment B at all. A
   toast confirms MainActivity received the numbers. This is hop 1 of the
   diagram: `Fragment A --activity.add(x,y)--> MainActivity`.
2. Tap **SEND DATA TO FRAGMENT B** — this button belongs to MainActivity
   itself, not to either Fragment (look at `activity_main.xml`: it's a
   sibling of the two `FrameLayout` containers, not inside `fragment_a.xml`
   or `fragment_b.xml`). MainActivity calls `fragmentB.addTwoNumbers(x, y)`
   directly on the Fragment B instance it already holds a reference to.
   This is hop 2: `MainActivity --fragB.addTwoNumbers(x,y)--> Fragment B`.
3. Fragment B (red box) updates its `RESULT` text to the sum — computed
   entirely inside Fragment B's own `addTwoNumbers()` method, matching the
   diagram's `int result = a + b;` line exactly.
4. The key point to land with students: `FragmentA.java` never imports
   `FragmentB`, and `FragmentB.java` never imports `FragmentA`. Have them
   grep for it — neither file mentions the other by name anywhere. The
   only class that imports and references both is `MainActivity`, which is
   exactly what the diagram's `interface MyListener` box is there to
   enforce: Fragment A is coupled to an interface, not to a concrete
   Fragment B.

## Project layout

```
app/src/main/java/com/example/interfragcomm/
  MyListener.java     - void add(int num1, int num2) — Fragment A's only
                        way to reach outward
  FragmentA.java       - collects two numbers, calls listener.add()
  FragmentB.java       - exposes addTwoNumbers(int a, int b), computes and
                        displays the sum; called only by MainActivity
  MainActivity.java    - implements MyListener; the only class aware of
                        both Fragments; forwards data on the second tap
app/src/main/res/layout/
  activity_main.xml    - app bar, yellow backdrop, Fragment A container,
                        SEND DATA TO FRAGMENT B button, Fragment B container
  fragment_a.xml        - "Fragment A" label, two number fields, send button
  fragment_b.xml         - "Fragment B" label, large RESULT text
```
