package com.example.interfragcomm;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

/**
 * The mediator. Matches the slide's diagram exactly:
 *
 *   Fragment A --activity.add(x,y)--> MainActivity (implements MyListener)
 *   MainActivity.add(x,y) { fragB.addTwoNumbers(x,y); }
 *   MainActivity --fragB.addTwoNumbers(x,y)--> Fragment B
 *
 * MainActivity is the ONLY class that knows both Fragment A and Fragment B
 * exist. Fragment A only knows MyListener; Fragment B only exposes
 * addTwoNumbers() and doesn't know who calls it. That's the "communication
 * gap" the slide calls out — the two Fragments never talk directly.
 *
 * This demo splits the diagram's single arrow into two separate button
 * taps on purpose, so each hop is visible on screen instead of happening
 * invisibly in one call: SEND DATA TO PARENT ACTIVITY (Fragment A -> this
 * Activity) is a separate, explicit step from SEND DATA TO FRAGMENT B
 * (this Activity -> Fragment B).
 */
public class MainActivity extends AppCompatActivity implements MyListener {

    private static final String TAG_A = "FragmentA";
    private static final String TAG_B = "FragmentB";

    private FragmentB fragmentB;

    // What MainActivity.add() most recently received from Fragment A.
    private int lastNum1 = 0;
    private int lastNum2 = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FragmentManager fm = getSupportFragmentManager();
        if (savedInstanceState == null) {
            FragmentTransaction ft = fm.beginTransaction();
            ft.add(R.id.fragment_container_a, new FragmentA(), TAG_A);
            fragmentB = new FragmentB();
            ft.add(R.id.fragment_container_b, fragmentB, TAG_B);
            ft.commit();
        } else {
            fragmentB = (FragmentB) fm.findFragmentByTag(TAG_B);
        }

        Button btnSendToFragmentB = findViewById(R.id.btnSendToFragmentB);
        btnSendToFragmentB.setOnClickListener(v -> fragmentB.addTwoNumbers(lastNum1, lastNum2));
    }

    /**
     * Called by Fragment A through MyListener. This Activity does not
     * forward straight to Fragment B here — it just remembers the numbers,
     * so the second hop stays a deliberate, visible button tap rather than
     * happening automatically the instant Fragment A sends data.
     */
    @Override
    public void add(int num1, int num2) {
        lastNum1 = num1;
        lastNum2 = num2;
        Toast.makeText(this, "MainActivity received " + num1 + " and " + num2
                + " from Fragment A. Tap SEND DATA TO FRAGMENT B to forward them.", Toast.LENGTH_SHORT).show();
    }
}
