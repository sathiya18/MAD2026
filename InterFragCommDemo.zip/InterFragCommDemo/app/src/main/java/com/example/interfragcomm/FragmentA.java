package com.example.interfragcomm;

import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * Hop 1 of "Sending data from one Fragment to another": Fragment A collects
 * two numbers and hands them to whatever Activity is hosting it, through
 * MyListener — exactly like the standalone Fragment-to-Activity demo.
 * Fragment A has no reference to Fragment B, no import of Fragment B, no
 * idea Fragment B even exists. That gap is the whole point of the slide's
 * note: "not communicating directly but creating a communication gap
 * between two fragments" — the Activity is the only thing that bridges it.
 */
public class FragmentA extends Fragment {

    private MyListener listener;
    private EditText etNum1;
    private EditText etNum2;

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof MyListener) {
            listener = (MyListener) context;
        } else {
            throw new ClassCastException(context + " must implement MyListener");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_a, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        etNum1 = view.findViewById(R.id.etNum1);
        etNum2 = view.findViewById(R.id.etNum2);
        Button btnSendToActivity = view.findViewById(R.id.btnSendToActivity);

        btnSendToActivity.setOnClickListener(v -> sendToActivity());
    }

    private void sendToActivity() {
        int num1;
        int num2;
        try {
            num1 = Integer.parseInt(etNum1.getText().toString().trim());
            num2 = Integer.parseInt(etNum2.getText().toString().trim());
        } catch (NumberFormatException e) {
            Toast.makeText(getContext(), "Enter two whole numbers first.", Toast.LENGTH_SHORT).show();
            return;
        }
        listener.add(num1, num2);
    }

    @Override
    public void onDetach() {
        super.onDetach();
        listener = null;
    }
}
