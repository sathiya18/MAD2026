package com.example.interfragcomm;

/**
 * The same contract from the Fragment-to-Activity demo, reused here as the
 * first hop of Fragment-to-Fragment communication. Fragment A only ever
 * talks to this interface — it has no idea Fragment B even exists.
 */
public interface MyListener {
    void add(int num1, int num2);
}
