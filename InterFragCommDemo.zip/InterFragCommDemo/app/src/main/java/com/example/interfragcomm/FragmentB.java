package com.example.interfragcomm;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

/**
 * Hop 2 of "Sending data from one Fragment to another": Fragment B never
 * hears from Fragment A directly. It only exposes one public method,
 * addTwoNumbers(), which MainActivity calls on the live Fragment B instance
 * it already holds a reference to — the same "Fragment object" technique
 * from the Activity-to-Fragment demo, just triggered from inside a
 * listener callback instead of a button click.
 */
public class FragmentB extends Fragment {

    private TextView tvResult;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                              @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_b, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        tvResult = view.findViewById(R.id.tvResult);
    }

    /** Matches the slide's diagram exactly: public void addTwoNumbers(int a, int b). */
    public void addTwoNumbers(int a, int b) {
        int result = a + b;
        if (tvResult != null) {
            tvResult.setText("RESULT: " + result);
        }
    }
}
