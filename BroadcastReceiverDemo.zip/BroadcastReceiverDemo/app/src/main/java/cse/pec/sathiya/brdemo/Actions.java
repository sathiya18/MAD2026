package cse.pec.sathiya.brdemo;

/**
 * Action names shared by the sender (MainActivity) and the receivers.
 * Keeping them in one place avoids typos in raw strings.
 */
public final class Actions {

    private Actions() { }

    /** Normal broadcast delivered to the three STATIC (manifest) receivers. */
    public static final String ACTION_STATIC_DEMO  = "cse.pec.sathiya.brdemo.ACTION_STATIC_DEMO";

    /** Ordered broadcast delivered to the STATIC receivers one by one, by priority. */
    public static final String ACTION_ORDERED_DEMO = "cse.pec.sathiya.brdemo.ACTION_ORDERED_DEMO";

    /** Custom broadcast delivered only to the DYNAMIC receiver registered in MainActivity. */
    public static final String ACTION_DYNAMIC_DEMO = "cse.pec.sathiya.brdemo.ACTION_DYNAMIC_DEMO";

    /** Extra key for the text message carried by the intent. */
    public static final String EXTRA_MESSAGE = "message";

    /** Logcat tag - filter Logcat with "BR_DEMO" to watch every receiver. */
    public static final String TAG = "BR_DEMO";
}
