package cse.pec.sathiya.brdemo;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

/**
 * STATIC receiver: declared in AndroidManifest.xml (priority 300).
 * Android creates a new object of this class for every broadcast,
 * calls onReceive() on the main thread, and then discards it.
 */
public class FirstReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();

        if (Actions.ACTION_STATIC_DEMO.equals(action)) {
            // Normal broadcast: all receivers get the same intent, in no fixed order
            String msg = intent.getStringExtra(Actions.EXTRA_MESSAGE);
            Log.d(Actions.TAG, "FirstReceiver got normal broadcast: " + msg);
            Toast.makeText(context, "FirstReceiver: " + msg, Toast.LENGTH_SHORT).show();

        } else if (Actions.ACTION_ORDERED_DEMO.equals(action) && isOrderedBroadcast()) {
            // Ordered broadcast: receivers run one at a time (priority 300).
            // Each one can read and change the "result data" before passing it on.
            String soFar = getResultData();
            setResultData(soFar + " → First");
            Log.d(Actions.TAG, "FirstReceiver (priority 300) passed on: " + getResultData());

            // Uncomment to STOP the chain here - later receivers will not run:
            // abortBroadcast();
        }
    }
}
