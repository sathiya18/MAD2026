package cse.pec.sathiya.brdemo;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {

    private TextView txtStaticResult;
    private TextView txtAirplane;
    private TextView txtBattery;
    private TextView txtDynamicResult;

    // =====================================================================
    // DYNAMIC (context-registered) receivers
    // - Created in code, NOT declared in the manifest.
    // - Registered in onStart(), unregistered in onStop():
    //   they only work while this screen is visible.
    // =====================================================================

    /** 1) System broadcast: airplane mode switched on/off. */
    private final BroadcastReceiver airplaneReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            boolean isOn = intent.getBooleanExtra("state", false);
            txtAirplane.setText(getString(R.string.airplane_status, isOn ? "ON" : "OFF"));
            Log.d(Actions.TAG, "Dynamic airplaneReceiver: airplane mode " + (isOn ? "ON" : "OFF"));
        }
    };

    /** 2) System broadcast: battery level / charging state changed. */
    private final BroadcastReceiver batteryReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            int percent = (level >= 0 && scale > 0) ? (level * 100 / scale) : -1;
            boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                    || status == BatteryManager.BATTERY_STATUS_FULL;
            txtBattery.setText(getString(R.string.battery_status, percent,
                    charging ? "charging" : "not charging"));
        }
    };

    /** 3) Custom in-app broadcast sent by the "Send dynamic broadcast" button. */
    private final BroadcastReceiver dynamicReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String msg = intent.getStringExtra(Actions.EXTRA_MESSAGE);
            txtDynamicResult.setText(getString(R.string.dynamic_result, msg));
            Log.d(Actions.TAG, "Dynamic dynamicReceiver got: " + msg);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        txtStaticResult = findViewById(R.id.txtStaticResult);
        txtAirplane = findViewById(R.id.txtAirplane);
        txtBattery = findViewById(R.id.txtBattery);
        txtDynamicResult = findViewById(R.id.txtDynamicResult);

        Button btnNormal = findViewById(R.id.btnSendNormal);
        Button btnOrdered = findViewById(R.id.btnSendOrdered);
        Button btnDynamic = findViewById(R.id.btnSendDynamic);

        btnNormal.setOnClickListener(v -> sendNormalStaticBroadcast());
        btnOrdered.setOnClickListener(v -> sendOrderedStaticBroadcast());
        btnDynamic.setOnClickListener(v -> sendDynamicBroadcast());
    }

    // ---------------------------------------------------------------------
    // PART A - STATIC receivers (FirstReceiver, SecondReceiver, ThirdReceiver)
    // ---------------------------------------------------------------------

    /** Normal broadcast: all three manifest receivers get it, in no fixed order. */
    private void sendNormalStaticBroadcast() {
        Intent intent = new Intent(Actions.ACTION_STATIC_DEMO);
        // Android 8+: manifest receivers only get EXPLICIT broadcasts.
        // setPackage() makes this broadcast explicit (only our app receives it).
        intent.setPackage(getPackageName());
        intent.putExtra(Actions.EXTRA_MESSAGE, "Hello from MainActivity");
        sendBroadcast(intent);

        txtStaticResult.setText(R.string.static_normal_sent);
    }

    /** Ordered broadcast: receivers run one by one - First(300) → Second(200) → Third(100). */
    private void sendOrderedStaticBroadcast() {
        Intent intent = new Intent(Actions.ACTION_ORDERED_DEMO);
        intent.setPackage(getPackageName());

        // This receiver runs LAST, after every manifest receiver has finished,
        // and shows the result data that was passed along the chain.
        BroadcastReceiver finalResult = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent i) {
                txtStaticResult.setText(getString(R.string.static_ordered_result, getResultData()));
            }
        };

        sendOrderedBroadcast(intent,
                null,               // no permission required
                finalResult,        // result receiver (runs at the end)
                null,               // scheduler: null = main thread
                Activity.RESULT_OK, // initial result code
                "Start",            // initial result data
                null);              // initial result extras
    }

    // ---------------------------------------------------------------------
    // PART B - DYNAMIC receivers (registered in code)
    // ---------------------------------------------------------------------

    /** Custom broadcast that only the dynamic receiver listens for. */
    private void sendDynamicBroadcast() {
        Intent intent = new Intent(Actions.ACTION_DYNAMIC_DEMO);
        intent.setPackage(getPackageName());
        intent.putExtra(Actions.EXTRA_MESSAGE, "Hello, dynamic receiver!");
        sendBroadcast(intent);
    }

    @Override
    protected void onStart() {
        super.onStart();

        // System broadcasts -> RECEIVER_EXPORTED (they come from outside our app).
        // ContextCompat.registerReceiver() works on all Android versions and
        // satisfies the Android 14+ rule that a flag must be given.
        ContextCompat.registerReceiver(this, airplaneReceiver,
                new IntentFilter(Intent.ACTION_AIRPLANE_MODE_CHANGED),
                ContextCompat.RECEIVER_EXPORTED);

        // ACTION_BATTERY_CHANGED is delivered immediately on registration
        // with the current value, and again whenever it changes.
        ContextCompat.registerReceiver(this, batteryReceiver,
                new IntentFilter(Intent.ACTION_BATTERY_CHANGED),
                ContextCompat.RECEIVER_EXPORTED);

        // Our own custom broadcast -> RECEIVER_NOT_EXPORTED (other apps cannot send it).
        ContextCompat.registerReceiver(this, dynamicReceiver,
                new IntentFilter(Actions.ACTION_DYNAMIC_DEMO),
                ContextCompat.RECEIVER_NOT_EXPORTED);

        Log.d(Actions.TAG, "Dynamic receivers REGISTERED (onStart)");
    }

    @Override
    protected void onStop() {
        super.onStop();
        // Always unregister what you registered - otherwise the receiver leaks.
        unregisterReceiver(airplaneReceiver);
        unregisterReceiver(batteryReceiver);
        unregisterReceiver(dynamicReceiver);
        Log.d(Actions.TAG, "Dynamic receivers UNREGISTERED (onStop)");
    }
}
