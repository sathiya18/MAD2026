plugins {
    id("com.android.application")
}

android {
    namespace = "cse.pec.sathiya.brdemo"
    compileSdk = 35

    defaultConfig {
        applicationId = "cse.pec.sathiya.brdemo"
        minSdk = 24
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    // Aligns all Kotlin stdlib pieces pulled in by AndroidX to one version.
    // Fixes "Duplicate class kotlin.* found in kotlin-stdlib and kotlin-stdlib-jdk7/jdk8".
    implementation(platform("org.jetbrains.kotlin:kotlin-bom:1.8.22"))

    implementation("androidx.appcompat:appcompat:1.7.0")
    // core 1.9.0+ is needed for ContextCompat.registerReceiver(..., flags)
    implementation("androidx.core:core:1.13.1")
}
