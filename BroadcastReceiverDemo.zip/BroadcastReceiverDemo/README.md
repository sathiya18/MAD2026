# Broadcast Receiver Demo: Static vs Dynamic

A one-screen Android app (Java) for classroom demonstration.

| Part | What it shows | Where |
|---|---|---|
| **A. Static** | 3 receivers declared in the manifest; a **normal** broadcast (all get it, any order) and an **ordered** broadcast (one by one, by priority) | `AndroidManifest.xml`, `FirstReceiver`, `SecondReceiver`, `ThirdReceiver` |
| **B. Dynamic** | Receivers registered in code for **airplane mode**, **battery**, and a **custom in-app** broadcast | `MainActivity` (`onStart()` / `onStop()`) |

Package: `cse.pec.sathiya.brdemo` · minSdk 24 · targetSdk 35 · Java 17

## Open and run

1. Android Studio → **File → Open** → select the `BroadcastReceiverDemo` folder.
2. Let Gradle sync. If Studio offers to upgrade the Android Gradle Plugin, accepting is fine.
3. Run on an emulator or phone (Android 7.0 or newer).
4. Open **Logcat** and filter by `BR_DEMO` to see every receiver fire.

## Classroom demo script

### A. Static receivers
1. Tap **Send normal broadcast** → three Toasts appear (First, Second, Third).
   Point out that the order is **not guaranteed** for a normal broadcast.
2. Tap **Send ordered broadcast** → the screen shows
   `Ordered result: Start → First → Second → Third`.
   Each receiver ran in turn (priority 300 → 200 → 100) and added its name.
3. Try it: uncomment `abortBroadcast();` in `FirstReceiver` and run again.
   The result becomes `Start → First`: the chain stopped.
4. Try it: remove `intent.setPackage(getPackageName());` in `sendNormalStaticBroadcast()`.
   **Nothing happens.** On Android 8+ manifest receivers don't get implicit custom broadcasts.

### B. Dynamic receivers
1. The **Battery** line fills in as soon as the screen opens. `ACTION_BATTERY_CHANGED`
   is delivered immediately on registration. On the emulator, change the battery
   level in *Extended controls → Battery* and watch it update.
2. Toggle **Airplane mode** from Quick Settings → the **Airplane mode** line updates.
3. Tap **Send dynamic broadcast** → the dynamic receiver shows the message.
4. Press **Home**, toggle airplane mode, then come back: the line did **not** change
   while the app was hidden, because the receivers were unregistered in `onStop()`.
   Logcat shows `REGISTERED` / `UNREGISTERED`.

## Key points to highlight

| | Static (manifest) | Dynamic (code) |
|---|---|---|
| Declared in | `AndroidManifest.xml` (`<receiver>`) | `ContextCompat.registerReceiver(...)` |
| Lives | Always, even when the app isn't open | Only between register and unregister |
| Android 8+ | Only explicit or exempted broadcasts | Implicit system broadcasts are OK |
| Security | `android:exported="false"` | `RECEIVER_EXPORTED` / `RECEIVER_NOT_EXPORTED` (required from Android 14) |
| Clean-up | none | Must call `unregisterReceiver()` |

`onReceive()` runs on the **main thread** and must finish within about 10 seconds, or the
app shows an ANR. Hand long work to **WorkManager**.
