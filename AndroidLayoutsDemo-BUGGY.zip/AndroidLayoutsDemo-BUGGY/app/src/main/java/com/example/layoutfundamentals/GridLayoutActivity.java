package com.example.layoutfundamentals;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class GridLayoutActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid_layout);
    }
}
