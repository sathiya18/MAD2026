package com.example.layoutfundamentals;

import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import androidx.appcompat.app.AppCompatActivity;

public class LinearLayoutActivity extends AppCompatActivity {

    private boolean isHorizontal = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_linear_layout);

        LinearLayout demo = findViewById(R.id.orientationDemo);
        Button toggle = findViewById(R.id.btnToggleOrientation);
        toggle.setOnClickListener(v -> {
            isHorizontal = !isHorizontal;
            demo.setOrientation(isHorizontal ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        });
    }
}
