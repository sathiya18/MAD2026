# Layout Fundamentals — Demo Project

A single Android Studio project demonstrating every layout type covered in the
"Exploring Basic Layouts" slide deck: LinearLayout, FrameLayout, RelativeLayout,
TableLayout, GridLayout, ConstraintLayout, and CoordinatorLayout.

## Opening the project

1. Open Android Studio → **File > Open** → select this folder.
2. Let Gradle sync (it will download the Gradle wrapper automatically the
   first time, using `gradle/wrapper/gradle-wrapper.properties`).
3. Run the `app` module on an emulator or device (minSdk 21).

## Structure

The app opens on `MainActivity`, a menu of buttons — one per layout type.
Each button launches a separate activity so every layout can be explored,
edited, and re-run independently.

| Activity | Layout file | Demonstrates |
|---|---|---|
| `LinearLayoutActivity` | `activity_linear_layout.xml` | Orientation toggle (tap the button to flip horizontal/vertical), `layout_gravity` vs `gravity`, `layout_weight` |
| `FrameLayoutActivity` | `activity_frame_layout.xml` | Stacking children; later children draw on top |
| `RelativeLayoutActivity` | `activity_relative_layout.xml` | `layout_centerHorizontal`, `layout_below`, `layout_toRightOf`, `layout_alignParentBottom` |
| `TableLayoutActivity` | `activity_table_layout.xml` | `TableRow`, `stretchColumns` |
| `GridLayoutActivity` | `activity_grid_layout.xml` | `columnCount`/`rowCount`, `layout_columnWeight` |
| `ConstraintLayoutActivity` | `activity_constraint_layout.xml` | A `Guideline` at 50%, a `Barrier` tracking the wider of two labels, a horizontal `chainStyle="spread"` |
| `CoordinatorLayoutActivity` | `activity_coordinator_layout.xml` | `AppBarLayout` + `CollapsingToolbarLayout`, scrolling content, a `FloatingActionButton` that shows a `Snackbar` |

## Notes for students

- Each activity is intentionally small and self-contained — open the paired
  `.xml`/`.java` file for any row on the menu and read them side by side.
- `LinearLayoutActivity` is the only interactive one (orientation toggle);
  the rest are static so the XML is the whole story.
- Colors used across the demos (`purple_light`, `green_light`, `blue_light`,
  etc.) live in `res/values/colors.xml` and match the palette used in the
  slide deck's mockups, so the on-screen result should look familiar.
- No launcher icon or app assets are bundled — Android Studio will use the
  default icon, keeping the project buildable without extra image files.
